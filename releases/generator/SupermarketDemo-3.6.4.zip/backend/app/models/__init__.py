"""Aggregate all models so ``Base.metadata`` is fully populated."""
from . import accounting, catalog, external, insights, inventory, marketing, sales, sync, system, user  # noqa: F401
from .accounting import (Account, CashSession, Cheque, Expense, ExpenseCategory,
                         FiscalPeriod, JournalEntry, JournalLine, Supplier)
from .base import SoftDeleteMixin, TimestampMixin
from .catalog import Brand, Category, Product, Unit
from .enums import *  # noqa: F401,F403
from .external import BankItem, ExternalSource, ImageAsset, MarketPrice, ProductResolverResult
from .inventory import (ProductBatch, StockMovement, Stocktake, StocktakeItem,
                        StorageLocation, Warehouse)
from .marketing import Campaign, Coupon, CouponRedemption
from .insights import Insight
from .sync import DiagnosticRun, SyncJob
from .pricing import PriceVersion
from .sales import (Customer, CustomerLedgerEntry, Invoice, InvoiceItem,
                    Payment, Return)
from .system import AuditLog, Counter, HardwareDevice, Notification, SmsMessage, SupportMessage, SupportTicket, SystemSetting
from .user import Permission, Role, User

__all__ = [
    "Base",
    "Account", "CashSession", "Cheque", "Expense", "ExpenseCategory", "FiscalPeriod",
    "JournalEntry", "JournalLine", "Supplier",
    "TimestampMixin",
    "SoftDeleteMixin",
    "User",
    "Role",
    "Permission",
    "Category",
    "Brand",
    "Unit",
    "Product",
    "ProductBatch",
    "PriceVersion",
    "StockMovement",
    "Stocktake",
    "StocktakeItem",
    "Warehouse",
    "StorageLocation",
    "Invoice",
    "InvoiceItem",
    "Payment",
    "Customer",
    "CustomerLedgerEntry",
    "Return",
    "ExternalSource",
    "ProductResolverResult",
    "ImageAsset",
    "MarketPrice",
    "SmsMessage",
    "HardwareDevice",
    "AuditLog",
    "Counter",
    "Notification",
    "Insight",
    "SystemSetting",
    "SupportTicket",
    "SupportMessage",
    "Campaign",
    "Coupon",
    "CouponRedemption",
    "SyncJob",
    "DiagnosticRun",
]
