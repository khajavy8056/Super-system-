from __future__ import annotations

import logging
from datetime import datetime, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Product, User
from ..security import get_current_user, has_permission, require_permission
from ..services import pos as pos_svc
from ..services.pos import CartItem, PosError
from ..services.reports import redact_costs

router = APIRouter(prefix="/pos", tags=["pos"])


def _maybe_redact(user: User, payload):
    """v3.7 (§34) — unit costs/profit leave the server only with ``pricing.view_cost``."""
    return payload if has_permission(user, "pricing.view_cost") else redact_costs(payload)


def _require_finite(name: str, v: Decimal) -> Decimal:
    """build-501 — NaN/∞ (از JSON خراب یا کلاینت معیوب) در مبدأ ۴۲۲ می‌شود، نه خطای ۵۰۰.
    هم‌ارزِ سمت گوشی: «Forbidden numeric value: NaN» دیگر هیچ‌مسیری به دیتابیس ندارد."""
    if not v.is_finite():
        raise ValueError(f"{name} must be a finite number")
    return v


class CartLineIn(BaseModel):
    product_id: int
    #: decimal quantities are first-class (12.500 Kg) — §25
    quantity: Decimal = Field(default=Decimal("1"), gt=0)
    batch_id: int | None = None
    discount: Decimal = Field(default=Decimal("0"), ge=0)

    @field_validator("quantity", "discount")
    @classmethod
    def _finite_line(cls, v: Decimal, info) -> Decimal:
        return _require_finite(str(info.field_name), v)


class CartIn(BaseModel):
    items: list[CartLineIn]
    tax_rate: Decimal | None = None
    coupon_code: str | None = None
    customer_id: int | None = None
    invoice_discount: Decimal | None = Field(default=None, ge=0)
    #: build-481 — cashier-selected campaign (validated server-side, §25)
    campaign_id: int | None = None


class PaymentIn(BaseModel):
    method: str = "CASH"
    amount: Decimal = Field(ge=0)

    @field_validator("amount")
    @classmethod
    def _finite_amount(cls, v: Decimal) -> Decimal:
        return _require_finite("amount", v)


from .customers import norm_phone as _norm_phone

log = logging.getLogger("supermarket.pos")


class CheckoutIn(BaseModel):
    items: list[CartLineIn]
    payments: list[PaymentIn]
    customer_id: int | None = None
    customer_phone: str | None = None
    customer_name: str | None = None
    tax_rate: Decimal | None = None
    coupon_code: str | None = None
    #: §12 whole-invoice discount (absolute amount in base currency)
    invoice_discount: Decimal | None = Field(default=None, ge=0)
    #: build-481 (§24) — festival picked from the POS list; the server re-validates
    campaign_id: int | None = None
    #: build-496 — offline terminals reserve their locally issued next-purchase code
    #: so queued checkouts can create the exact same coupon on the server.
    client_issued_coupon_codes: dict[str, str] = Field(default_factory=dict)
    #: §19 pulse the cash drawer after a successful cash sale
    open_drawer: bool = False

    @field_validator("tax_rate", "invoice_discount")
    @classmethod
    def _finite_optional(cls, v: Decimal | None, info) -> Decimal | None:
        return None if v is None else _require_finite(str(info.field_name), v)


# --- Kiosk / lock mode (§7) ---------------------------------------------------

@router.get("/kiosk/config")
def kiosk_config(db: Session = Depends(get_db),
                 _: User = Depends(get_current_user)):
    """Config the POS terminal needs to enter kiosk mode (any logged-in user)."""
    shortcut = pos_svc.get_setting(db, "pos.kiosk_shortcut", "Ctrl+Shift+L")
    store = pos_svc.get_setting(db, "printer.header", "") or "فروشگاه"
    return {"shortcut": shortcut, "store_name": store.split("\n")[0],
            "tax_rate": pos_svc.get_setting(db, "pos.tax_rate", "0")}


class KioskUnlockIn(BaseModel):
    username: str
    password: str


@router.post("/kiosk/unlock")
def kiosk_unlock(body: KioskUnlockIn, db: Session = Depends(get_db)):
    """Leaving kiosk requires admin credentials (§7 security note).

    Returns ok=True ONLY for a valid, active user holding ``settings.manage``.
    No token is issued — the cashier session stays as-is; this only unlocks
    the terminal UI. Failed attempts are audited and rate-limited by the same
    login throttling machinery.
    """
    from ..models import User as UserModel
    from ..security import _user_permission_codes, verify_password
    from ..services.audit import write_audit
    from sqlalchemy import select as _select

    user = db.execute(_select(UserModel).where(UserModel.username == body.username)).scalar_one_or_none()
    if not user or not user.is_active or not verify_password(body.password, user.password_hash):
        write_audit(db, action="KIOSK_UNLOCK_FAILED", reference=body.username)
        db.commit()
        raise HTTPException(status_code=401, detail="ادمین معتبر نیست")
    if "settings.manage" not in _user_permission_codes(user):
        write_audit(db, action="KIOSK_UNLOCK_DENIED", user_id=user.id, reference=body.username)
        db.commit()
        raise HTTPException(status_code=403, detail="این کاربر اجازه خروج از حالت کیوسک ندارد")
    write_audit(db, action="KIOSK_UNLOCKED", user_id=user.id, entity_type="User", entity_id=user.id)
    db.commit()
    return {"ok": True}


@router.get("/batch-options/{product_id}")
def batch_options(product_id: int, db: Session = Depends(get_db), user: User = Depends(require_permission("pos.sell"))):
    product = db.get(Product, product_id)
    if not product or product.deleted_at is not None or not product.is_active:
        raise HTTPException(status_code=404, detail="PRODUCT_NOT_FOUND")
    options = pos_svc.get_batch_options(db, product)
    return _maybe_redact(user, {"product_id": product_id, "product_name": product.name,
                                "mode": pos_svc.get_setting(db, "pos.batch_selection_mode", "HYBRID"),
                                "options": [o.as_dict() for o in options]})


class CampaignListIn(BaseModel):
    amount: Decimal = Field(ge=0)
    product_ids: list[int] | None = None
    line_amounts: dict[int, Decimal] | None = None
    customer_id: int | None = None
    include_auto_apply: bool = True


@router.post("/campaigns/eligible")
def eligible_campaigns(body: CampaignListIn, db: Session = Depends(get_db),
                       user: User = Depends(require_permission("pos.sell"))):
    """build-481 (§24) — the structured festival list a cashier chooses from.

    Returns ONLY campaigns whose conditions already hold for this basket —
    active, inside their window, over the minimum purchase, usage slots left.
    Selecting one is a convenience; checkout re-validates everything (§25).
    """
    from ..services import coupons as coupon_svc
    amount = Decimal(str(body.amount))
    rejections: list[dict] = []   # build-512 — دلیل رد شدن هر جشنوارهٔ فعال
    rows = coupon_svc.eligible_campaigns(
        db, amount=amount, product_ids=body.product_ids,
        line_amounts={int(k): Decimal(str(v)) for k, v in (body.line_amounts or {}).items()},
        customer_id=body.customer_id, include_auto_apply=body.include_auto_apply,
        rejected=rejections,
    )
    # build-509 — «با ثبت این فاکتور کوپن خرید بعدی صادر می‌شود»: صندوق‌دار قبل از
    # ثبت بداند کدام جشنواره‌های آستانه‌دار فعال‌اند (درخواست مالک برای شفافیت صندوق).
    issue_now = coupon_svc.issue_on_checkout(
        db, amount=amount, customer_id=body.customer_id)
    # build-512 — rejections همیشه هست: صندوق (و هر کلاینتی) بلافاصله می‌فهمد چرا
    # یک جشنوارهٔ خاص با این سبد جمع نشد؛ حتی وقتی جشنوارهٔ واجد شرایط دیگری هست.
    return {"campaigns": rows, "count": len(rows), "issue_on_checkout": issue_now,
            "rejections": rejections}


@router.post("/cart/validate")
def validate_cart(body: CartIn, db: Session = Depends(get_db), user: User = Depends(require_permission("pos.sell"))):
    try:
        items = pos_svc.validate_cart(db, [CartItem(product_id=i.product_id, quantity=i.quantity,
                                                   batch_id=i.batch_id, discount=i.discount)
                                           for i in body.items])
        totals = _totals(items)
        if body.invoice_discount:
            inv_disc = Decimal(str(body.invoice_discount))
            if inv_disc > Decimal(str(totals["subtotal"])):
                raise HTTPException(status_code=422, detail={"code": "INVALID_DISCOUNT",
                                    "message": "تخفیف فاکتور از مبلغ سبد بیشتر است"})
            totals["invoice_discount"] = float(inv_disc)
            totals["discount"] = float(Decimal(str(totals["discount"])) + inv_disc)
            totals["subtotal"] = float(Decimal(str(totals["subtotal"])) - inv_disc)
        coupon = None
        if body.coupon_code:
            from ..services import coupons as coupon_svc

            phone = None
            if body.customer_id:
                from ..models import Customer
                cust = db.get(Customer, body.customer_id)
                phone = cust.phone if cust else None
            try:
                ev = coupon_svc.evaluate(db, code=body.coupon_code,
                                         amount=Decimal(str(totals["subtotal"])),
                                         customer_id=body.customer_id, customer_phone=phone)
                coupon = {"code": ev["code"], "discount": float(ev["discount"]),
                          "campaign": ev["campaign"], "ok": True}
                totals["coupon_discount"] = float(ev["discount"])
                totals["subtotal"] = float(Decimal(str(totals["subtotal"])) - ev["discount"])
            except coupon_svc.CouponError as exc:
                coupon = {"code": body.coupon_code, "ok": False,
                          "error_code": exc.code, "message": exc.message}
        campaign = None
        if body.campaign_id:
            from ..services import coupons as camp_svc
            line_amounts: dict[int, Decimal] = {}
            for i in items:
                line_amounts[i.product_id] = line_amounts.get(i.product_id, Decimal("0")) + (
                    (i.unit_sell_price or Decimal("0")) * i.quantity - i.discount)
            try:
                ev = camp_svc.evaluate_campaign(
                    db, campaign_id=body.campaign_id,
                    amount=Decimal(str(totals["subtotal"])),
                    product_ids=[i.product_id for i in items], line_amounts=line_amounts,
                    customer_id=body.customer_id)
                campaign = {"campaign_id": ev["campaign_id"], "name": ev["name"],
                            "discount": float(ev["discount"]), "ok": True,
                            "stackable": ev["stackable"]}
                totals["campaign_discount"] = float(ev["discount"])
                totals["subtotal"] = float(Decimal(str(totals["subtotal"])) - ev["discount"])
            except camp_svc.CampaignError as exc:
                campaign = {"campaign_id": body.campaign_id, "ok": False,
                            "error_code": exc.code, "message": exc.message}
        return _maybe_redact(user, {"items": [_line_out(i) for i in items], "totals": totals,
                                    "coupon": coupon, "campaign": campaign})
    except PosError as e:
        raise HTTPException(status_code=422, detail={"code": e.code, "message": e.message})


@router.post("/checkout", status_code=201)
def checkout(body: CheckoutIn, db: Session = Depends(get_db),
             user: User = Depends(require_permission("pos.sell"))):
    try:
        # v4.8.0 — «تخفیفِ اجراشده باید روی صندوق باشد»: پیش از هر فروش، پله‌های
        # تخفیف انقضایی که امروز موعدشان رسیده اعمال می‌شوند. کارگر پس‌زمینه هم
        # این کار را می‌کند، اما فروشگاهی که کارگر را خاموش کرده نباید کالای
        # «تخفیف‌خورده در تئوری» را به قیمت قدیم بفروشد. عمل idempotent است.
        from ..services import insight_actions as _ia
        try:
            _ia.apply_markdown_steps(db)
        except Exception:
            log.exception("markdown steps skipped before checkout")   # never block a sale
        customer_id = body.customer_id
        if customer_id is None and body.customer_phone:
            # Phone book: a phone number alone is enough to create a customer (§30)
            from ..models import Customer

            # v3.1: any phone typed at checkout (e.g. only for the invoice SMS) lands in the
            # customer book automatically — last name optional — so the next purchase with the
            # same number is recognised and VIP/churn/basket analytics apply to it.
            phone = _norm_phone(body.customer_phone)
            cust = None
            if phone:
                cust = db.execute(select(Customer).where(Customer.phone == phone)).scalar_one_or_none()
                if cust is None:
                    cust = Customer(name=(body.customer_name or "").strip() or f"مشتری {phone}", phone=phone)
                    db.add(cust)
                    db.flush()
            if cust is not None:
                customer_id = cust.id
        invoice = pos_svc.checkout(
            db,
            items=[CartItem(product_id=i.product_id, quantity=i.quantity, batch_id=i.batch_id,
                           discount=i.discount)
                   for i in body.items],
            payments=[p.model_dump() for p in body.payments],
            user=user,
            customer_id=customer_id,
            tax_rate=body.tax_rate,
            coupon_code=body.coupon_code,
            invoice_discount=body.invoice_discount,
            campaign_id=body.campaign_id,
        )

        # Next-purchase coupon (§36) + invoice SMS are issued after the sale is
        # built but INSIDE the same transaction, so nothing is half-committed.
        from ..models import Customer as _C
        from ..services import coupons as coupon_svc

        customer = db.get(_C, customer_id) if customer_id else None
        issued = coupon_svc.issue_next_purchase_coupon(
            db, invoice=invoice, customer=customer, user=user,
            preferred_codes=body.client_issued_coupon_codes)

        from ..services import sms as sms_svc
        # v2.3 — invoice SMS is independent of receipt printing: the shop may turn the
        # printer off (pos.print_after_checkout=false) and still text every invoice.
        sms_on = sms_svc.get_setting(db, "sms.send_invoice", "true").strip().lower() != "false"
        if sms_on and customer and customer.phone:
            from ..services import sync as sync_svc

            # §172/§162 — invoice SMS from the shop-editable pattern (§166);
            # the next-purchase coupon rides along in the same message.
            coupon_line = ""
            if issued:
                coupon_line = f"کد تخفیف خرید بعدی: {issued.code}"
                if issued.valid_until:
                    # v4.8.0 — تاریخ شمسی با ارقام فارسی (متن پیامک یکدست می‌ماند)
                    from ..services.timeservice import to_jalali
                    d = issued.valid_until.date()
                    jy, jm, jd = to_jalali(datetime(d.year, d.month, d.day))
                    coupon_line += (f" (تا {jy:04d}/{jm:02d}/{jd:02d})"
                                    .translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")))
            text = sms_svc.render_invoice_for_mode(db, invoice, coupon_line)
            msg = sms_svc.queue_sms(db, phone=customer.phone, text=text,
                                    reference_type="Invoice", reference_id=invoice.id)
            # queued for retry-safe delivery; never blocks the sale (§48)
            sync_svc.enqueue(db, job_type="SMS", payload={"sms_id": msg.id},
                             reference_type="Invoice", reference_id=invoice.id,
                             idempotency_key=f"sms:invoice:{invoice.id}", user_id=user.id)
            # «به محض تأیید فاکتور»: try to hand it to the provider right away; the
            # queue/worker above still guarantees retry if the network is down.
            if sms_svc.get_setting(db, "sms.send_immediately", "true").strip().lower() != "false":
                sms_svc.kick_worker()

        out = _invoice_out(invoice)
        # §19 — cash drawer opens on cash tenders (never blocks the sale)
        out["drawer"] = None
        if body.open_drawer or any(str(p.method).upper() == "CASH" for p in body.payments):
            from ..services import hardware as hw_svc
            ok, msg = hw_svc.open_cash_drawer(db)
            out["drawer"] = {"ok": ok, "message": msg}
        out["coupon_code"] = body.coupon_code
        # build-481: do NOT echo body.campaign_id over the applied one — for an
        # auto-applied threshold festival the request carries None while the
        # invoice really was discounted by a campaign.
        # build-509 — جزئیات کامل کوپن صادرشده برای نمایش در صندوق و رسید
        out["issued_coupon"] = ({"code": issued.code,
                                 "valid_until": issued.valid_until.isoformat()
                                 if issued.valid_until else None,
                                 "discount_type": issued.discount_type,
                                 "discount_value": float(issued.discount_value),
                                 "min_purchase": float(issued.min_purchase or 0),
                                 "campaign_name": (issued.campaign.name if issued.campaign else None)}
                                if issued else None)
        db.commit()
        return _maybe_redact(user, out)
    except PosError as e:
        db.rollback()
        raise HTTPException(status_code=422, detail={"code": e.code, "message": e.message})


def _line_out(i: CartItem) -> dict:
    return {
        "product_id": i.product_id, "product_name": i.product_name,
        "batch_id": i.batch_id, "batch_number": i.batch_number,
        "quantity": float(i.quantity),
        "unit_buy_price": float(i.unit_buy_price or 0),
        "unit_consumer_price": float(i.unit_consumer_price or 0),
        "unit_sell_price": float(i.unit_sell_price or 0),
        "discount": float(i.discount), "subtotal": float(i.subtotal), "profit": float(i.profit),
        "expiry_date": str(i.expiry_date) if i.expiry_date else None,
        "suggested": i.suggested,
    }


def _totals(items: list[CartItem]) -> dict:
    gross = sum(((i.unit_sell_price or Decimal("0")) * i.quantity for i in items), Decimal("0"))
    discount = sum((i.discount for i in items), Decimal("0"))
    return {
        "gross": float(gross),
        "discount": float(discount),
        "subtotal": float(gross - discount),
        "profit": float(sum((i.profit for i in items), Decimal("0"))),
        "count": len(items),
    }


def _invoice_out(inv) -> dict:
    return {
        "invoice_id": inv.id,
        "invoice_number": inv.invoice_number,
        "subtotal": float(inv.subtotal),
        "discount": float(inv.discount),
        "invoice_discount": float(getattr(inv, "invoice_discount", 0) or 0),
        "tax": float(inv.tax),
        "total_amount": float(inv.total_amount),
        "payment_method": inv.payment_method,
        # exposed so the POS can show "نسیه / روی حساب" instead of implying the
        # money was collected — an ACCOUNT sale is credit, not cash received
        "payment_status": inv.payment_status,
        "status": inv.status,
        "print_status": inv.print_status,
        "customer_id": inv.customer_id,
        # build-481 (§26) — which festival/coupon granted what, frozen at sale time
        "campaign_id": getattr(inv, "campaign_id", None),
        "campaign_name": getattr(inv, "campaign_name", None),
        "benefit_source": getattr(inv, "benefit_source", "NONE"),
        "benefit_amount": float(getattr(inv, "benefit_amount", 0) or 0),
        "applied_coupon_code": getattr(inv, "applied_coupon_code", None),
        "items": [
            {"product_id": it.product_id, "batch_id": it.batch_id, "qty": float(it.qty),
             "qty_display": float(it.qty),
             "unit_buy_price": float(it.unit_buy_price), "unit_sell_price": float(it.unit_sell_price),
             "discount": float(it.discount), "subtotal": float(it.subtotal), "profit": float(it.profit)}
            for it in inv.items
        ],
    }


# --- POS search (§26) ------------------------------------------------------------

@router.get("/search")
def pos_search(q: str, limit: int = 20, db: Session = Depends(get_db),
               user: User = Depends(require_permission("pos.sell"))):
    """Cashier search by barcode, product name, SKU or product code.

    An exact barcode/SKU hit is always returned first so scanning stays instant,
    then partial name matches for typed searches (e.g. «شیر»).
    """
    from ..models import Brand, ProductBatch, Unit
    from sqlalchemy import func as _f

    from ..services import product_search as search
    term = (q or "").strip().translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
    if not term:
        return {"query": q, "items": []}

    exact = db.execute(
        select(Product).where(
            Product.deleted_at.is_(None),
            (Product.barcode == term) | (_f.lower(Product.sku) == term.lower()),
        )
    ).scalars().all()

    like = "%" + search.literal_like(search.normalize(term)) + "%"
    # §18 — brand is searchable too: a cashier types «دماوند» (the brand)
    # far more often than the full product name.
    brand_ids = db.execute(
        select(Brand.id).where(Brand.name.ilike(like, escape="\\"))
    ).scalars().all()
    conditions = ((search.name_column(Product.name).like(like, escape="\\")) | (Product.barcode.ilike(like, escape="\\"))
                  | (Product.sku.ilike(like, escape="\\")) | (Product.model.ilike(like, escape="\\")))
    if brand_ids:
        conditions = conditions | (Product.brand_id.in_(brand_ids))
    # v3.5 — the default catalogue made a typed search return hundreds of rows the
    # shop does not stock, burying the ones it does. Order the partial matches by
    # "can I actually sell this right now", then alphabetically inside each group.
    # An exact barcode/SKU hit still wins outright, so scanning stays instant.
    stock = (
        select(ProductBatch.product_id,
               _f.coalesce(_f.sum(ProductBatch.current_qty), 0).label("qty"))
        .where(ProductBatch.current_qty > 0, ProductBatch.status == "ACTIVE")
        .group_by(ProductBatch.product_id)
        .subquery()
    )
    available = _f.coalesce(stock.c.qty, 0)
    partial = db.execute(
        select(Product).where(
            Product.deleted_at.is_(None),
            Product.is_active.is_(True),
            conditions,
        ).outerjoin(stock, Product.id == stock.c.product_id)
        .order_by((available > 0).desc(), search.rank(Product.name, term), Product.name.collate("PERSIAN"), Product.id).limit(limit)
    ).scalars().all()

    seen: set[int] = set()
    ordered: list[Product] = []
    for p in exact + partial:
        if p.id not in seen:
            seen.add(p.id)
            ordered.append(p)

    items = []
    for p in ordered[:limit]:
        options = pos_svc.get_batch_options(db, p)
        unit = db.get(Unit, p.unit_id) if p.unit_id else None
        total = float(sum((o.batch.current_qty for o in options), 0))
        items.append({
            "product_id": p.id, "name": p.name, "barcode": p.barcode, "sku": p.sku,
            "image_url": p.image_url,
            "unit": {"name": unit.name, "symbol": unit.symbol,
                     "allow_decimal": unit.allow_decimal,
                     "decimals": unit.decimals} if unit else None,
            "available_qty": total,
            "price_count": len({float(o.batch.sell_price) for o in options}),
            "exact": p in exact,
            "batches": [o.as_dict() for o in options],
        })
    return _maybe_redact(user, {"query": term, "count": len(items), "items": items})


@router.get("/fast-movers")
def pos_fast_movers(days: int = 30, limit: int = 16, db: Session = Depends(get_db),
                    user: User = Depends(require_permission("pos.sell"))):
    """build-508 — نوار «پرفروش‌ها» صندوق (درخواست مالک): پرفروش‌ترین کالاهای
    روزهای اخیر با تصویر، به‌شکل نواری افقی بالای صندوق تا صندوق‌دار با یک لمس
    پرفروش‌ها را به سبد بیفزاید — بدون تایپ و جست‌وجو.

    خروجی عیناً همان شکل آیتم‌های /pos/search است (batches/unit/available_qty)،
    یعنی کلیک روی هر کاشی مستقیماً همان مسیر افزودن جست‌وجو را می‌رود (انتخاب بچ/
    تعداد خودکار). فقط کالایی که همین حالا قابل فروش است (بچ فعال با موجودی) نشان
    داده می‌شود؛ فاکتورهای ابطال‌شده در شمارش پرفروشی نمی‌آیند.
    """
    from sqlalchemy import desc, func

    from ..models import Invoice, InvoiceItem, Unit
    days = max(1, min(int(days), 365))
    limit = max(1, min(int(limit), 40))
    since = datetime.utcnow() - timedelta(days=days)
    rows = db.execute(
        select(InvoiceItem.product_id,
               func.sum(InvoiceItem.qty).label("sq"),
               func.sum(InvoiceItem.subtotal).label("st"))
        .join(Invoice, Invoice.id == InvoiceItem.invoice_id)
        .where(InvoiceItem.created_at >= since, Invoice.status != "VOID")
        .group_by(InvoiceItem.product_id)
        .order_by(desc("sq"), InvoiceItem.product_id)
        .limit(limit * 3)   # چند ردیف اضافه: کالای حذف‌شده/بی‌موجودی بعداً حذف می‌شود
    ).all()
    items = []
    for pid, sq, st in rows:
        if len(items) >= limit:
            break
        p = db.get(Product, pid)
        if p is None or p.deleted_at is not None or not p.is_active:
            continue
        options = pos_svc.get_batch_options(db, p)
        total = float(sum((o.batch.current_qty for o in options), 0))
        if total <= 0:
            continue   # نوار پرفروش‌ها فقط «الان قابل فروش» را پیشنهاد می‌دهد
        unit = db.get(Unit, p.unit_id) if p.unit_id else None
        items.append({
            "product_id": p.id, "name": p.name, "barcode": p.barcode, "sku": p.sku,
            "image_url": p.image_url,
            "unit": {"name": unit.name, "symbol": unit.symbol,
                     "allow_decimal": unit.allow_decimal,
                     "decimals": unit.decimals} if unit else None,
            "available_qty": total,
            "price_count": len({float(o.batch.sell_price) for o in options}),
            "exact": False,
            "batches": [o.as_dict() for o in options],
            "sold_qty": float(sq or 0),
            "sold_total": float(st or 0),
        })
    return _maybe_redact(user, {"days": days, "count": len(items), "items": items})
