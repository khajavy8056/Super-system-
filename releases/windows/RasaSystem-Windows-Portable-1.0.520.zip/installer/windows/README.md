# ساخت فایل نصبی ویندوز — راهنمای گام‌به‌گام

> **خلاصهٔ یک‌خطی:** کل مخزن را دانلود کنید (Code → Download ZIP یا clone)،
> وارد پوشهٔ `installer\windows` شوید و روی **`BUILD-SETUP.bat` دابل‌کلیک کنید.**
> همین!

## پیش‌نیازها

| پیش‌نیاز | الزام | توضیح |
|---|---|---|
| ویندوز | 10 یا 11 | 64-bit |
| **Python** | 3.9+ (پیشنهادی 3.11+) | از [python.org](https://www.python.org/downloads/) نصب کنید و حتماً تیک **«Add python.exe to PATH»** را موقع نصب بزنید |
| **Inno Setup 6** | *اختیاری* | فقط برای ساخت `Setup.exe` کلاسیک — از [jrsoftware.org](https://jrsoftware.org/isdl.php). اگر نباشد، خروجی **Portable** (تک‌فایل اجرایی بدون نیاز به نصب) ساخته می‌شود |

اتصال اینترنت برای بار اول لازم است (نصب وابستگی‌ها).

## خروجی‌ها

| فایل | مسیر | توضیح |
|---|---|---|
| `RasaSystem-Setup-1.0.496.exe` | `installer\output\` | نصب‌کنندهٔ کلاسیک (نیاز به Inno Setup) — شماره از `backend/app/__init__.py` |
| `RasaSystem-1.0.496-portable.exe` | `installer\output\` | تک‌فایل قابل اجرا بدون نصب — همیشه ساخته می‌شود |
| `RasaSystem.exe` | `installer\windows\dist\` | همان فایل portable قبل از کپی |
| `build.log` | `installer\windows\` | لاگ کامل ساخت |

**داده‌های برنامه** (دیتابیس، لاگ‌ها، کلید) در `%USERPROFILE%\RasaSystem`
ساخته می‌شوند — حذف یا به‌روزرسانی برنامه آن‌ها را پاک نمی‌کند. نسخه‌های قدیمی‌تر ممکن است از `%USERPROFILE%\SupermarketSystem` استفاده کرده باشند.

## حذف کامل نسخه‌ها و نصب از صفر (عملیات مخرب)

برای پاک‌کردن نصب‌های ثبت‌شدهٔ `Rasa System` / `Supermarket System` و داده‌های محلی پیش از نصب تازه:

1. هر دو فایل `RESET-TO-FRESH-INSTALL.bat` و `RESET-TO-FRESH-INSTALL.ps1` را کنار هم نگه دارید.
2. BAT را اجرا کنید و برای تأیید حذف برگشت‌ناپذیر دقیقاً بنویسید `RESET RASA SYSTEM`.
3. ابزار فرایندهای برنامه را می‌بندد، در صورت امکان حذف‌کنندهٔ Inno Setup را اجرا می‌کند، پوشه‌های نصب شناخته‌شده و میانبرها را جمع می‌کند و هر دو پوشهٔ دادهٔ `%USERPROFILE%\RasaSystem` و `%USERPROFILE%\SupermarketSystem` را حذف می‌کند.
4. بعد از پیام موفقیت، نصب‌کنندهٔ نسخهٔ جدید را جداگانه اجرا کنید؛ اجرای اول باید دیتابیس خالی بسازد.

این ابزار **برای به‌روزرسانی معمولی نیست**؛ دیتابیس، بکاپ‌های داخل پوشهٔ برنامه، لاگ‌ها، کلید محلی و داده‌های وب‌ویو را حذف می‌کند. پیش‌نمایش بدون حذف:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\RESET-TO-FRESH-INSTALL.ps1 -WhatIf
```

فایل‌های بکاپ/نصب‌کننده در Downloads یا مسیرهای دلخواه، اطلاعات روی تلفن/سرور، و داده‌ای که با `DATABASE_URL` یا `SUPERMARKET_DATA_DIR` سفارشی به مسیر دیگری منتقل شده باشد، خودکار جست‌وجو یا حذف نمی‌شود. اگر فایل‌های نصب در `Program Files` باقی ماندند، BAT را با دسترسی Administrator و همان حساب ویندوزی که برنامه را نصب کرده اجرا کنید.

## ساخت پشت‌صحنهٔ BUILD-SETUP.bat چه می‌کند؟

1. **بررسی کامل بودن مخزن** — وجود ۱۰ فایل حیاتی (backend، frontend، spec، icon و…).
2. پیدا کردن Python (از PATH یا `py` launcher) + بررسی نسخه.
3. ساخت venv در `backend\.venv` و نصب `requirements.txt` + PyInstaller.
4. ساخت اجرایی تک‌فایل با PyInstaller (`app.spec`) — صحت ساخت چک می‌شود.
5. کپی خروجی Portable به `installer\output\`.
6. اگر Inno Setup 6 نصب باشد: ساخت `Setup.exe` با `setup.iss` — و صحت فایل چک می‌شود.

هر مرحله اگر شکست بخورد، **دلیل دقیق و قابل‌اقدام** چاپ و با کد 1 خارج می‌شود؛
لاگ کامل در `build.log` هست.

## عیب‌یابی خطاهای رایج

| خطا / علامت | ریشه | راه‌حل |
|---|---|---|
| `project files are missing` / «فایل‌های پروژه نبوده» | مخزن ناقص کپی شده — BUILD-SETUP.bat بیرون از مخزن اجرا شده | کل مخزن را دانلود کنید (Code → Download ZIP از شاخهٔ درست) و فایل را جابه‌جا نکنید |
| خطاهای «کامپایلری» با شمارهٔ خطوط مختلف + کد 1 | نسخهٔ قدیمی/شاخهٔ اشتباه پروژه (فایل‌های builder قدیمی) | از شاخهٔ به‌روزشده بسازید؛ فایل‌های سازندهٔ قدیمی (`builder-gui.ps1` و…) حذف شده‌اند و جای آن‌ها `BUILD-SETUP.bat` + `build.ps1` ساده و تست‌شده است |
| `Python not found` | پایتون نصب نیست یا در PATH نیست | python.org → نصب با تیک «Add python.exe to PATH» → دوباره اجرا |
| پنجره بسته می‌شود و چیزی نمی‌بینید | اجرای مستقیم ps1 بدون کنسول | از `BUILD-SETUP.bat` اجرا کنید (خودش کنسول را نگه می‌دارد) |
| `Inno Setup 6 not found` | Inno نصب نیست | لازم نیست! Portable ساخته شده؛ برای Setup.exe آن را نصب کنید و دوباره بیلد بگیرید |
| `Could not find a version that satisfies the requirement pywebview` / `Read timed out ... pypi.org` (v1.4.0) | اینترنت به pypi.org نمی‌رسد (تحریم/فیلتر/کندی) و pywebview فقط از آنجا نصب می‌شد | **از v1.4.1 رفع شد:** pywebview اختیاری است (`backend\requirements-desktop.txt`)؛ سازنده با timeout ۶۰ ثانیه و ۸ تلاش، سپس با آینه‌های جایگزین (runflare, iranrepo, tuna, aliyun) تلاش می‌کند؛ اگر باز هم نشد **ساخت ادامه می‌یابد** و برنامه در پنجرهٔ Edge (app-mode) باز می‌شود. برای پنجرهٔ بومی به‌صورت آفلاین: فایل‌های wheel (`pywebview`, `pythonnet`, `clr_loader`, `bottle`, `proxy_tools`, `typing_extensions`, `cffi`, `pycparser`) را در `installer\windows\wheels\` بگذارید |
| `Read timed out` روی بسته‌های اصلی (fastapi و…) | همان مشکل شبکه | VPN/DNS دیگر، یا یک بار روی سیستمی با اینترنت: `pip download -r backend\requirements.txt pyinstaller -d installer\windows\wheels` و پوشه را کنار مخزن کپی کنید؛ سازنده خودکار از آن استفاده می‌کند |
| `ValueError: not enough values to unpack (expected 3, got 2)` در مرحلهٔ ۵ (PyInstaller / `app.spec` خط `EXE(`) | ورودی‌های ۲تایی هوک pywebview مستقیماً به TOC اضافه می‌شدند (v1.4.1) | **از v1.4.2 رفع شد** (`_as_toc` در `app.spec`)؛ از ZIP نسخهٔ جدید بسازید |
| SmartScreen هنگام اجرای exe | فایل امضای دیجیتال ندارد (عادی است) | More info → Run anyway |
| آنتی‌ویروس exe را می‌گیرد | PyInstaller onefile گاهی false-positive می‌دهد | استثنا گذاشتن یا استفاده از نسخهٔ portable در پوشهٔ خود پروژه |

## اجرای دستی (بدون فایل bat)

```powershell
cd installer\windows
powershell -NoProfile -ExecutionPolicy Bypass -File build.ps1
```

## اجرای برنامه بدون ساخت نصب‌کننده (توسعه)

```powershell
cd backend
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
.venv\Scripts\python ..\installer\windows\run_supermarket.py
```

مرورگر بعد از آماده‌شدن سرور (`/health` = 200) خودش باز می‌شود.
ورود پیش‌فرض: `admin` / `admin123` (در اولین اجرا عوض کنید).

## وضعیت تست‌شدگی (شفافیت کامل)

- منطق لانچرِ frozen (همان `run_supermarket.py`) روی لینوکس با cx_Freeze بیلد و
  **به‌صورت کامل بوت‌تست شده**: health 200، ورود JWT، سرو پنل/موبایل، ساخت DB
  با ۲۹ جدول، پایداری کلید بین ری‌استارت‌ها (جزئیات: `docs/BUILD.md`).
- ساختِ PyInstaller روی ویندوز + Setup.exeٔ Inno: اسکریپت‌ها ساده و دفاعی
  نوشته شده‌اند اما چون sandbox ویندوز ندارد، **UNTESTED روی ویندوز واقعی** ثبت
  شده — به همین دلیل هر مرحله خروجی‌اش چک می‌شود و پیام خطا دقیق می‌دهد.


## پایتون از قبل نصب است ولی پیدا نمی‌شود؟ (v1.2.2)

سازنده به این ترتیب می‌گردد: متغیر محیطی `SUPERMARKET_PYTHON` → رجیستری ویندوز (PEP 514) → `py -0p` → PATH → پوشه‌های استاندارد. اگر باز هم پیدا نشد، مسیر کامل را خودتان بدهید:

```bat
set SUPERMARKET_PYTHON=C:\Path\To\python.exe
BUILD-SETUP.bat
```

گزارش کامل جست‌وجو (هر کاندیدای رد‌شده با دلیل) در `installer\windows\build.log` ثبت می‌شود.
