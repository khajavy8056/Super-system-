"""Windows/standalone launcher — starts the local sync backend and opens the
NATIVE Windows application (Qt widgets, no browser/webview/cookies).

Used by the frozen executable (PyInstaller, onefile) and directly in dev:

    python installer/windows/run_supermarket.py

Design notes:
- User data (SQLite DB, logs, per-install JWT secret) lives in ``~/RasaSystem``
  so reinstalling/updating the app never wipes data.
- The JWT secret is generated once per install and persisted — tokens survive
  restarts (root-cause fix vs falling back to the dev default key).
- The native window opens only after ``/health`` answers 200 (real readiness
  probe), not after a bare TCP connect.

Desktop contract (build-498, دستورالعمل §۶):
- The Windows app is a NATIVE Qt Widgets application (no HTML/CSS/JS, no
  WebView, no browser, no cookies, no web cache). Business logic is called
  in-process through the same service layer the server uses.
- The local HTTP server stays alive ONLY for the Android app's LAN sync and
  pairing — the desktop UI never depends on it.
- A browser is never a fallback. Missing native UI dependencies are an
  explicit startup failure with repair instructions.

Window contract (4.8.1 / build 482, unchanged):
- The program is installed on shop POS machines and MUST open FULL SCREEN by
  default. SUPERMARKET_KIOSK=0 switches back to a normal resizable window
  (repair/development); SUPERMARKET_KIOSK=kiosk requests full-screen without a
  frame (locked-down till).
"""
from __future__ import annotations

import logging
import os
import secrets
import socket
import sys
import threading
import time
import urllib.request
from pathlib import Path

# v1.0.0 (RASA) — brand + data folder. The folder is RasaSystem for new installs;
# an existing ~/SupermarketSystem (v4.x and older) is taken over once, IN PLACE, so
# an update never loses the shop's database. Both names are recognised forever.
APP_NAME = "RasaSystem"
LEGACY_APP_NAME = "SupermarketSystem"


def backend_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))  # type: ignore[arg-type]
    return Path(__file__).resolve().parent.parent.parent / "backend"


def data_dir() -> Path:
    """User data folder — migrates the pre-1.0 folder name without touching the data."""
    base = Path.home() / APP_NAME
    legacy = Path.home() / LEGACY_APP_NAME
    if not base.exists() and legacy.exists():
        try:
            legacy.rename(base)                       # same volume: atomic, nothing is copied
        except OSError:
            import shutil
            shutil.copytree(legacy, base)             # different volume (rare): copy, keep the original
    (base / "logs").mkdir(parents=True, exist_ok=True)
    return base


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


PREFERRED_PORT = 8765


def stable_port(base: Path) -> int:
    """v2.3 — the phones remember the PC by *port* as well as IP, so the port
    must not change between launches. Order: SUPERMARKET_PORT env → the port
    used last time (``server.port.last``) → 8765 → the first free port after it.
    Whatever is chosen is exported as ``PORT`` so the backend's LAN beacon and
    pairing QR advertise the *real* port (v2.2 advertised 8000 while listening
    on a random port — the phone then re-found the PC at the wrong port)."""
    env = os.environ.get("SUPERMARKET_PORT", "").strip()
    candidates: list[int] = []
    if env.isdigit():
        candidates.append(int(env))
    lf = base / "server.port.last"
    try:
        candidates.append(int(lf.read_text(encoding="utf-8").strip()))
    except (OSError, ValueError):
        pass
    candidates += [PREFERRED_PORT + i for i in range(0, 20)]
    for port in candidates:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("0.0.0.0", port))
            except OSError:
                continue
        try:
            lf.write_text(str(port), encoding="utf-8")
        except OSError:
            pass
        os.environ["PORT"] = str(port)
        return port
    port = free_port()
    os.environ["PORT"] = str(port)
    return port


def persistent_secret(base: Path) -> str:
    """Return SECRET_KEY from env, or the per-install persisted key, or a new one."""
    env_key = os.environ.get("SECRET_KEY", "").strip()
    if env_key:
        return env_key
    key_file = base / "secret.key"
    if key_file.exists():
        key = key_file.read_text(encoding="utf-8").strip()
        if key:
            return key
    key = secrets.token_hex(32)
    key_file.write_text(key, encoding="utf-8")
    try:  # best-effort: only the user may read the key
        os.chmod(key_file, 0o600)
    except OSError:
        pass
    return key


def purge_stale_webview_cache(base: Path) -> None:
    """build-498 — پاک‌سازی باقی‌ماندهٔ پروفایل WebView2 نسخه‌های قدیمی.

    برنامهٔ ویندوز از بیلد ۴۹۸ به بعد کاملاً نیتیو (Qt) است و هیچ پروفایلی
    نگه نمی‌دارد؛ این تابع فقط میراث نصب‌های قبلی را پاک می‌کند تا کوکی/کش
    قدیمی هیچ اثری روی اطلاعات نگذارد (دستورالعمل §۶/§۷)."""
    import shutil
    try:
        from app import __version__
    except Exception:
        return
    ver_file = base / "ui.version"
    prev = ver_file.read_text(encoding="utf-8").strip() if ver_file.exists() else ""
    if prev == __version__:
        return
    wv = base / "webview2"
    if wv.exists():
        for sub in (
            "EBWebView/Default/Cache",
            "EBWebView/Default/Code Cache",
            "EBWebView/Default/Service Worker",
            "Default/Cache",
            "Default/Code Cache",
            "Default/Service Worker",
        ):
            target = wv / sub
            if target.exists():
                shutil.rmtree(target, ignore_errors=True)
    try:
        ver_file.write_text(__version__, encoding="utf-8")
    except OSError:
        pass


def wait_healthy(port: int, timeout: float = 30.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=1.0) as resp:
                if resp.status == 200:
                    return True
        except OSError:
            pass
        time.sleep(0.25)
    return False


# ---------------------------------------------------------------------------
# §19 — the NATIVE Windows application (build-498, دستورالعمل §۶)
# ---------------------------------------------------------------------------
def open_native_app(base: Path, log) -> bool:
    """بازکردن «برنامهٔ بومی ویندوز» — Qt Widgets، بدون مرورگر/WebView/کوکی.

    build-498: رابط کاربری ویندوز دیگر HTML در WebView2 نیست؛ یک برنامهٔ
    دسکتاپ واقعی با ویجت‌های نیتیو است که منطق کسب‌وکار را درون همان پروسه
    صدا می‌زند. سرور محلی فقط برای همگام‌سازی گوشی اندروید در LAN زنده است.
    Returns True when the app was shown (blocks until it closes); False when
    the native UI dependencies are missing so the caller shows repair notes.
    """
    if not getattr(sys, "frozen", False):
        repo_root = str(backend_dir().parent)
        if repo_root not in sys.path:
            sys.path.insert(0, repo_root)
    try:
        from desktop.main import run_desktop_app  # noqa: PLC0415
    except Exception as exc:  # noqa: BLE001
        log.warning("native desktop UI not available (%s); native startup blocked", exc)
        return False
    try:
        from app import __version__ as app_version  # noqa: PLC0415
    except Exception:  # noqa: BLE001
        app_version = ""
    log.info("opening the native Qt desktop application")
    run_desktop_app(data_dir=base, version=app_version)
    return True


def native_window_error(log_file):
    _message_box(
        "برنامهٔ بومی ویندوز راه‌اندازی نشد (هیچ پنجرهٔ وبی جایگزین نمی‌شود).\n\n"
        "نصب برنامه را ترمیم کنید؛ کتابخانهٔ رابط نیتیو (PySide6/Qt) باید همراه "
        "نسخهٔ ویندوز نصب شده باشد.\n\n"
        f"گزارش خطا: {log_file}"
    )


def _bind_std_streams(log_file: Path) -> None:
    """In a windowed (console=False) PyInstaller build ``sys.stdout`` and
    ``sys.stderr`` are ``None``. Anything that touches them - ``print``,
    ``logging.StreamHandler(sys.stdout)``, uvicorn's default log config
    (``sys.stdout.isatty()``) - raises, and because the server ran on a
    daemon thread that exception was swallowed: the process sat idle with no
    window and no error (the v1.2.5 report). Redirect both streams to the
    log file so nothing can ever trip on a missing console again."""
    if sys.stdout is None or sys.stderr is None or getattr(sys, "frozen", False):
        try:
            fh = open(log_file, "a", encoding="utf-8", buffering=1)
            if sys.stdout is None or getattr(sys, "frozen", False):
                sys.stdout = fh
            if sys.stderr is None or getattr(sys, "frozen", False):
                sys.stderr = fh
        except OSError:
            import io

            sys.stdout = sys.stdout or io.StringIO()
            sys.stderr = sys.stderr or io.StringIO()


def _message_box(text: str, title: str = "Supermarket System", icon: int = 0x10) -> None:
    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(None, text, title, icon | 0x100000)  # MB_RTLREADING
    except Exception:
        print(text, file=sys.stderr)


def _single_instance_port(base: Path) -> int | None:
    """If a previous instance is still serving, return its port so a second
    click re-opens the window instead of silently starting a duplicate."""
    pf = base / "server.port"
    try:
        port = int(pf.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=1.0) as resp:
            if resp.status == 200:
                return port
    except OSError:
        pass
    return None


def main() -> None:
    base = data_dir()
    log_file = base / "logs" / "supermarket.log"
    _bind_std_streams(log_file)
    sys.path.insert(0, str(backend_dir()))

    os.environ.setdefault("DATABASE_URL", f"sqlite:///{base / 'supermarket.db'}")
    # v4.0 — one data dir for everything the app persists (DB, logs, brain models,
    # llama.cpp runtime). Without this the frozen backend would resolve its data
    # dir inside the PyInstaller temp extraction dir and lose the model the
    # installer placed in ~/SupermarketSystem/brain/models on every launch.
    os.environ.setdefault("SUPERMARKET_DATA_DIR", str(base))
    os.environ.setdefault("SECRET_KEY", persistent_secret(base))
    os.environ.setdefault("SUPERMARKET_ALLOW_SHUTDOWN", "1")   # v1.6: in-app exit button
    purge_stale_webview_cache(base)
    if getattr(sys, "frozen", False):
        os.environ.setdefault("ENVIRONMENT", "production")

    handlers: list[logging.Handler] = [logging.FileHandler(log_file, encoding="utf-8")]
    if not getattr(sys, "frozen", False) and sys.stdout is not None:
        handlers.append(logging.StreamHandler(sys.stdout))
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=handlers,
        force=True,
    )
    logging.getLogger("alembic").setLevel(logging.WARNING)
    log = logging.getLogger("launcher")
    log.info("=== launcher start (frozen=%s, exe=%s) ===", getattr(sys, "frozen", False), sys.executable)

    # Second click while already running -> just bring the panel up again.
    running = _single_instance_port(base)
    if running:
        log.info("instance already running on port %s; opening the window only", running)
        if not open_native_app(base, log):
            native_window_error(log_file)
        return

    import uvicorn
    from app.database import init_db

    init_db()

    port = stable_port(base)
    (base / "server.port").write_text(str(port), encoding="utf-8")
    log.info("data dir: %s", base)
    log.info("log file: %s", log_file)

    server_error: dict = {}

    def serve() -> None:
        try:
            # log_config=None: uvicorn's default dictConfig builds console
            # formatters that call sys.stdout.isatty(); with the root logger
            # already configured to the file above, plain propagation is
            # exactly what we want.
            # v1.6: listen on all interfaces so the Android app can reach the
            # shop PC over Wi-Fi (the pairing QR embeds the LAN address).
            uvicorn.run("app.main:app", host=os.environ.get("SUPERMARKET_HOST", "0.0.0.0"), port=port,
                        log_level="warning", log_config=None)
        except BaseException as exc:  # noqa: BLE001
            server_error["exc"] = exc
            log.exception("backend server crashed")

    server = threading.Thread(target=serve, name="uvicorn", daemon=True)
    server.start()

    url = f"http://127.0.0.1:{port}"
    log.info("Supermarket System is starting at %s (local API for Android sync)", url)
    if wait_healthy(port):
        log.info("healthy, opening the native desktop application")
        if open_native_app(base, log):
            log.info("native application closed; shutting down")
            try:
                (base / "server.port").unlink()
            except OSError:
                pass
            return
        native_window_error(log_file)
        try:
            (base / "server.port").unlink()
        except OSError:
            pass
        return
    else:
        detail = f"{type(server_error['exc']).__name__}: {server_error['exc']}" if server_error else "سرور در ۳۰ ثانیه آماده نشد."
        log.error("backend did not become healthy: %s", detail)
        _message_box(
            "برنامه نتوانست سرویس داخلی خود را راه‌اندازی کند.\n\n"
            f"{detail[:600]}\n\n"
            f"گزارش کامل: {log_file}\n"
            "در صورت تکرار، این فایل را برای پشتیبانی ارسال کنید."
        )
        sys.exit(1)

    try:
        while True:
            time.sleep(1)
            if server_error:
                raise RuntimeError(f"backend stopped: {server_error['exc']}")
            # If the user closes the application window the process should end
            # too, otherwise a headless server is left holding the port and the
            # shortcut appears to "do nothing" on the next launch.
            if window is not None and window.poll() is not None:
                log.info("application window closed (exit %s); shutting down",
                         window.returncode)
                break
    except KeyboardInterrupt:
        pass
    finally:
        try:
            (base / "server.port").unlink()
        except OSError:
            pass


def _fatal(exc: BaseException) -> None:
    """Show a readable message (and where the log is) instead of PyInstaller's
    raw 'Unhandled exception in script' dialog; the full traceback is logged."""
    import traceback

    base = data_dir()
    log_file = base / "logs" / "supermarket.log"
    try:
        with open(log_file, "a", encoding="utf-8") as fh:
            fh.write("\n=== FATAL on startup ===\n" + traceback.format_exc())
    except Exception:
        pass
    msg = (
        "برنامه هنگام شروع با خطا مواجه شد و اجرا نشد.\n\n"
        f"{type(exc).__name__}: {str(exc)[:600]}\n\n"
        f"گزارش کامل: {log_file}\n"
        f"پایگاه داده: {base / 'supermarket.db'}\n\n"
        "اگر این خطا پس از به‌روزرسانی رخ داده، از پایگاه داده نسخهٔ پشتیبان بگیرید و دوباره اجرا کنید؛ "
        "در صورت تکرار، فایل گزارش را برای پشتیبانی ارسال کنید."
    )
    _message_box(msg)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except Exception as exc:  # noqa: BLE001
        _fatal(exc)
        sys.exit(1)
