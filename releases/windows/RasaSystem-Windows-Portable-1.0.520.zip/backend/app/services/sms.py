"""SMS service — real providers + background dispatch worker (BUG-015).

Providers (configurable via settings):
- ``melipayamak``: Iranian SMS panel (username/password/sender) — REST API.
- ``kavenegar``:  Iranian SMS panel (api_key) — REST API.
- ``file``:       dev/test sink — writes messages to a file (honest, no network).
- ``fail``:       test provider that always fails (retry/FAILED path).

Honesty rules:
- No provider configured -> messages stay PENDING (never faked as SENT).
- Failures are classified, stored (error_message) and retried up to
  ``sms.max_retries`` with the RETRYING status; then FAILED.
- Live delivery to melipayamak/kavenegar requires internet egress; in this
  sandbox that was NOT possible, so those adapters are implemented but marked
  UNTESTED-LIVE in TEST_REPORT (no fake success claimed).
"""
from __future__ import annotations

import json
import logging
import random
import threading
from datetime import datetime, timedelta
from pathlib import Path

import httpx
from sqlalchemy import or_, select, update
from sqlalchemy.orm import Session

from ..config import settings as app_settings
from ..models import SmsMessage, SystemSetting

_worker: threading.Thread | None = None
_stop = threading.Event()



def _lt_today():
    from .timeservice import local_today
    return local_today()


def _lt_now():
    from .timeservice import local_now
    return local_now()

class SmsProviderError(Exception):
    def __init__(self, kind: str, detail: str = ""):
        super().__init__(f"{kind}: {detail}")
        self.kind = kind
        self.detail = detail


def get_setting(db: Session, key: str, default: str) -> str:
    row = db.execute(select(SystemSetting).where(SystemSetting.key == key)).scalar_one_or_none()
    return row.value if row else default


def _set_setting(db: Session, key: str, value: str) -> None:
    row = db.execute(select(SystemSetting).where(SystemSetting.key == key)).scalar_one_or_none()
    if row is None:
        db.add(SystemSetting(key=key, value=value, description="v2.8 phone SIM sender state", is_secret=False))
    else:
        row.value = value
    db.flush()


# --- Providers ----------------------------------------------------------------

MELIPAYAMAK_BASE = "https://rest.payamak-panel.com/api/SendSMS"

# RetStatus codes documented by Melipayamak for SendSMS / BaseServiceNumber.
MELIPAYAMAK_STATUS = {
    0: "نام کاربری یا رمز عبور اشتباه است", 1: "ارسال موفق", 2: "اعتبار کافی نیست",
    3: "محدودیت در ارسال روزانه", 4: "محدودیت در حجم ارسال", 5: "شماره فرستنده معتبر نیست",
    6: "سامانه در حال بروزرسانی است", 7: "متن حاوی کلمهٔ فیلترشده است",
    9: "ارسال از خطوط عمومی از طریق وب‌سرویس امکان‌پذیر نیست", 10: "کاربر مورد نظر فعال نیست",
    11: "ارسال نشد", 12: "مدارک کاربر کامل نیست", 14: "متن حاوی لینک است",
    15: "ارسال به بیش از ۱ شماره بدون درج «لغو۱۱» ممکن نیست", 16: "شمارهٔ گیرنده‌ای یافت نشد",
    17: "متن پیامک خالی است", 35: "شماره در لیست سیاه مخابرات است",
}


def _melipayamak_base(db: Session) -> str:
    """Endpoint override for tests / self-hosted proxies (sms.melipayamak_url)."""
    return (get_setting(db, "sms.melipayamak_url", "") or MELIPAYAMAK_BASE).rstrip("/")


def _melipayamak_post(db: Session, method: str, data: dict) -> dict:
    """POST like the official client does: form-encoded, JSON back.
    Reference: github.com/Melipayamak/melipayamak-python (sms/rest.py)."""
    username = get_setting(db, "sms.username", "")
    password = get_setting(db, "sms.password", "")
    if not (username and password):
        raise SmsProviderError("CONFIG_MISSING", "sms.username/sms.password required")
    try:
        resp = httpx.post(f"{_melipayamak_base(db)}/{method}",
                          data={"username": username, "password": password, **data},
                          timeout=app_settings.EXTERNAL_TIMEOUT_SECONDS)
    except httpx.HTTPError as exc:
        raise SmsProviderError("NETWORK", type(exc).__name__) from exc
    if resp.status_code != 200:
        raise SmsProviderError(f"HTTP_{resp.status_code}", resp.text[:200])
    try:
        body = resp.json()
    except ValueError as exc:
        raise SmsProviderError("INVALID_RESPONSE", resp.text[:200]) from exc
    if not isinstance(body, dict):
        raise SmsProviderError("INVALID_RESPONSE", str(body)[:200])
    return body


def _melipayamak_check(body: dict) -> None:
    """Melipayamak signals success with RetStatus==1 and Value = RecId (a long
    number). A small Value together with RetStatus!=1 is an error code."""
    ret = body.get("RetStatus")
    try:
        ret = int(ret)
    except (TypeError, ValueError):
        ret = None
    if ret == 1:
        return
    code = ret if ret is not None else body.get("Value")
    try:
        code_i = int(code)
    except (TypeError, ValueError):
        code_i = -1
    raise SmsProviderError(f"MELI_{code}", MELIPAYAMAK_STATUS.get(code_i, body.get("StrRetStatus") or str(body)[:120]))


def _send_melipayamak(db: Session, phone: str, text: str) -> str:
    """§165 — Melipayamak. Two modes:

    * ``sms.melipayamak_mode = line``   → ``SendSMS`` from the shop's own line
      (``sms.sender``). Needs a dedicated line; public lines are refused (9).
    * ``sms.melipayamak_mode = pattern`` → ``BaseServiceNumber`` (خط خدماتی
      اشتراکی) with ``sms.melipayamak_body_id``; the message text is sent as the
      pattern variables joined by ';' (§166). Works without a dedicated line
      and is not affected by carrier advertising filters.
    """
    mode = (get_setting(db, "sms.melipayamak_mode", "line") or "line").strip().lower()
    if mode == "pattern":
        body_id = get_setting(db, "sms.melipayamak_body_id", "").strip()
        if not body_id:
            raise SmsProviderError("CONFIG_MISSING", "sms.melipayamak_body_id required for pattern mode")
        # a pattern takes positional variables; we send each line as one variable
        variables = ";".join(part.strip() for part in text.split("\n") if part.strip())
        body = _melipayamak_post(db, "BaseServiceNumber", {"text": variables, "to": phone, "bodyId": body_id})
    else:
        sender = get_setting(db, "sms.sender", "")
        if not sender:
            raise SmsProviderError("CONFIG_MISSING", "sms.sender required (line mode)")
        body = _melipayamak_post(db, "SendSMS", {"to": phone, "from": sender, "text": text, "isFlash": "false"})
    _melipayamak_check(body)
    return json.dumps(body, ensure_ascii=False)


def melipayamak_credit(db: Session) -> dict:
    """GetCredit — used by the connection test (§177)."""
    body = _melipayamak_post(db, "GetCredit", {})
    _melipayamak_check(body)
    return {"credit": body.get("Value"), "raw": body}


def melipayamak_delivery(db: Session, rec_id: str) -> dict:
    """GetDeliveries2 — delivery status of a sent message (§170)."""
    return _melipayamak_post(db, "GetDeliveries2", {"recId": rec_id})


def _send_kavenegar(db: Session, phone: str, text: str) -> str:
    api_key = get_setting(db, "sms.api_key", "")
    if not api_key:
        raise SmsProviderError("CONFIG_MISSING", "sms.api_key required")
    try:
        resp = httpx.get(
            f"https://api.kavenegar.com/v1/{api_key}/sms/send.json",
            params={"receptor": phone, "message": text},
            timeout=app_settings.EXTERNAL_TIMEOUT_SECONDS,
        )
    except httpx.HTTPError as exc:
        raise SmsProviderError("NETWORK", type(exc).__name__) from exc
    if resp.status_code == 429:
        raise SmsProviderError("RATE_LIMITED", resp.text[:200])
    if resp.status_code != 200:
        raise SmsProviderError(f"HTTP_{resp.status_code}", resp.text[:200])
    return resp.text[:500]


def _send_file(db: Session, phone: str, text: str) -> str:
    """Deterministic dev/test sink — proves the whole pipeline without network."""
    path = get_setting(db, "sms.file_path", "data/sms_out.log")
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps({"phone": phone, "text": text,
                            "at": datetime.utcnow().isoformat()}, ensure_ascii=False) + "\n")
    return f"file:{p}"


def _send_fail(db: Session, phone: str, text: str) -> str:
    raise SmsProviderError("ALWAYS_FAIL", "test provider")


def _send_phone(db: Session, phone: str, text: str) -> str:
    """v2.8 — provider «phone»: the message is NOT sent here. A paired Android device that
    has «ارسال با سیم‌کارت» enabled pulls PENDING rows from /sms/outbox, sends them through
    its SIM and reports back. Raising HANDOFF keeps the row PENDING without a retry."""
    raise SmsProviderError("HANDOFF", "در انتظار ارسال از سیم‌کارت گوشی")


PROVIDERS = {
    "phone": _send_phone,
    "melipayamak": _send_melipayamak,
    "kavenegar": _send_kavenegar,
    "file": _send_file,
    "fail": _send_fail,
}


# --- Enqueue / single dispatch ---------------------------------------------------

def queue_sms(db: Session, *, phone: str, text: str,
              reference_type: str | None = None, reference_id: int | None = None) -> SmsMessage:
    """Persist a message as PENDING. The worker delivers it (offline-safe)."""
    msg = SmsMessage(phone=phone.strip(), text=text.strip(), status="PENDING",
                     reference_type=reference_type, reference_id=reference_id)
    db.add(msg)
    db.flush()
    return msg


def _audit(db: Session, action: str, msg: "SmsMessage", provider: str,
           error: str | None = None) -> None:
    """Write the §43 SMS_SENT / SMS_FAILED audit row.

    Auditing must never be the reason a message fails to send, so a broken
    audit write is swallowed after being logged — the SMS state is the primary
    record and it is already committed by the caller.
    """
    try:
        from .audit import write_audit

        write_audit(db, action=action, entity_type="SmsMessage", entity_id=msg.id,
                    reference=msg.phone,
                    after={"provider": provider, "status": msg.status,
                           "retry_count": msg.retry_count, "error": error})
    except Exception:  # pragma: no cover - defensive
        logging.getLogger("supermarket.sms").exception("audit write failed for %s", action)


def dispatch_one(db: Session, sms_id: int) -> str:
    """Send a single message now; raises SmsProviderError so the sync queue
    can apply its backoff policy."""
    msg = db.get(SmsMessage, sms_id)
    if msg is None:
        raise SmsProviderError("NOT_FOUND", f"sms {sms_id}")
    if msg.status == "SENT":
        return "ALREADY_SENT"
    provider_code = get_setting(db, "sms.provider", "").strip()
    sender = PROVIDERS.get(provider_code)
    if sender is None:
        raise SmsProviderError("CONFIG_MISSING", f"provider={provider_code or 'none'}")
    response = sender(db, msg.phone, msg.text)
    msg.status = "SENT"
    msg.sent_at = datetime.utcnow()
    msg.provider_response = response
    msg.error_message = None
    # §43 — SMS_SENT belongs in the audit trail, not only in the message row.
    _audit(db, "SMS_SENT", msg, provider_code)
    db.flush()
    return response


# --- Dispatcher ----------------------------------------------------------------

def retry_delay_seconds(retry_count: int, *, base: int = 60, cap: int = 3600) -> float:
    """v3.8 — exponential backoff with jitter: min(cap, base·2ⁿ) + U[0, base].

    The jitter decorrelates concurrent workers so a provider outage does not
    turn into a synchronized retry stampede when it recovers.
    """
    return min(cap, base * (2 ** max(0, retry_count - 1))) + random.uniform(0, base)


def _backoff_cfg(db: Session) -> tuple[int, int]:
    try:
        base = max(1, int(get_setting(db, "sms.backoff_base_seconds", "60") or 60))
    except ValueError:
        base = 60
    try:
        cap = max(base, int(get_setting(db, "sms.backoff_max_seconds", "3600") or 3600))
    except ValueError:
        cap = 3600
    return base, cap


def dispatch_pending(db: Session, *, limit: int = 20) -> dict:
    """Process due PENDING/RETRYING messages once. Returns an honest summary.

    v3.8 race control: each message is CLAIMED (PENDING/RETRYING → SENDING) in
    its own committed transaction and only the worker that won the claim sends
    it — two dispatchers can no longer double-send the same row. A SENDING row
    whose worker died (no update for 10 minutes) becomes claimable again.
    """
    from ..models import SmsMessage as _M
    provider_code = get_setting(db, "sms.provider", "").strip()
    max_retries = int(get_setting(db, "sms.max_retries", "5") or 5)
    base, cap = _backoff_cfg(db)
    now = datetime.utcnow()

    stmt = select(SmsMessage.id).where(
        or_(SmsMessage.status.in_(["PENDING", "RETRYING"]),
            # stuck-claim recovery: a SENDING row untouched for 10+ minutes
            # belongs to a dead worker and re-enters the queue.
            (SmsMessage.status == "SENDING") & (SmsMessage.updated_at < now - timedelta(minutes=10)))
    ).order_by(SmsMessage.id.asc()).limit(limit * 2)
    candidate_ids = list(db.execute(stmt).scalars())

    summary = {"provider": provider_code or None, "sent": 0, "retrying": 0,
               "failed": 0, "skipped": 0, "not_due": 0, "lost_race": 0}

    if not provider_code:
        # No provider configured — do NOT touch the messages (stay PENDING).
        summary["skipped"] = len(candidate_ids)
        summary["reason"] = "NO_PROVIDER_CONFIGURED"
        return summary

    sender = PROVIDERS.get(provider_code)
    if sender is None:
        summary["skipped"] = len(candidate_ids)
        summary["reason"] = f"UNKNOWN_PROVIDER:{provider_code}"
        return summary

    if provider_code == "phone":
        # nothing to do on the PC — the phone drains the outbox itself
        summary["skipped"] = len(candidate_ids)
        summary["reason"] = "PHONE_SIM_HANDOFF"
        return summary

    done = 0
    for mid in candidate_ids:
        if done >= limit:
            break
        # CLAIM in its own transaction: exactly one dispatcher wins the row.
        claimed = db.execute(
            update(_M).where(_M.id == mid, _M.status.in_(["PENDING", "RETRYING", "SENDING"]))
            .values(status="SENDING")).rowcount
        db.commit()
        if not claimed:
            summary["lost_race"] += 1
            continue
        msg = db.get(SmsMessage, mid)
        # Backoff gate: a RETRYING row sleeps until next_retry_at.
        if msg.next_retry_at is not None and msg.next_retry_at > datetime.utcnow():
            msg.status = "RETRYING"
            db.commit()
            summary["not_due"] += 1
            continue
        done += 1
        try:
            response = sender(db, msg.phone, msg.text)
            msg.status = "SENT"
            msg.sent_at = datetime.utcnow()
            msg.provider_response = response
            msg.error_message = None
            msg.next_retry_at = None
            summary["sent"] += 1
            _audit(db, "SMS_SENT", msg, provider_code)
        except SmsProviderError as exc:
            msg.retry_count = (msg.retry_count or 0) + 1
            msg.error_message = f"{exc.kind}: {exc.detail}"[:500]
            if msg.retry_count >= max_retries:
                msg.status = "FAILED"
                msg.next_retry_at = None
                summary["failed"] += 1
                # Only the terminal failure is audited: a message that is still
                # going to be retried has not failed yet, and logging every
                # attempt would bury the audit log in noise.
                _audit(db, "SMS_FAILED", msg, provider_code,
                       error=f"{exc.kind}: {exc.detail}")
            else:
                msg.status = "RETRYING"
                delay = retry_delay_seconds(msg.retry_count, base=base, cap=cap)
                msg.next_retry_at = datetime.utcnow() + timedelta(seconds=delay)
                summary["retrying"] += 1
        db.commit()
    return summary


# --- Background worker -----------------------------------------------------------

_wake = threading.Event()


def kick_worker() -> None:
    """Wake the dispatcher now (invoice SMS must go out the moment the sale is confirmed)."""
    _wake.set()


def start_worker(session_factory) -> None:
    """Start the background dispatch thread (idempotent)."""
    global _worker
    if _worker and _worker.is_alive():
        return
    _stop.clear()

    def run():
        while not _stop.is_set():
            try:
                db = session_factory()
                try:
                    interval = int(get_setting(db, "sms.worker_interval_seconds", "10") or 10)
                    dispatch_pending(db)
                finally:
                    db.close()
            except Exception:  # never let the worker die silently
                import logging
                logging.getLogger("supermarket.sms").exception("sms worker tick failed")
                interval = 10
            # sleep until the next tick — or until a checkout kicks us (v2.3)
            _wake.wait(max(3, min(interval, 300)))
            _wake.clear()

    _worker = threading.Thread(target=run, name="sms-worker", daemon=True)
    _worker.start()


def stop_worker() -> None:
    _wake.set()
    _stop.set()


# --- §166 templates / §173–§176 typed messages / §171 manual retry -----------

TEMPLATE_KEYS = {
    #: v4.8.0 — قالب فاکتور حالا «{items}» دارد: ردیف‌های مرتب کالاها (یک ردیف
    #: برای هر کالا). قالب کهنهٔ تک‌خطی هم پشتیبانی می‌شود و در آن حالت ردیف‌ها
    #: به پیام اضافه می‌شوند — هرگز خطوط خریداری‌شده حذف نمی‌شوند.
    "invoice": ("sms.template.invoice",
                "{store} | فاکتور {invoice}\n{items}\nاز خرید شما سپاسگزاریم"),
    "debt_reminder": ("sms.template.debt_reminder",
                      "{customer} گرامی، مانده بدهی شما نزد {store} مبلغ {amount} {currency} است. با تشکر."),
    "coupon": ("sms.template.coupon",
               "{store} | کد تخفیف شما: {code} | تا {until} معتبر است"),
    "low_stock": ("sms.template.low_stock",
                  "{store} | هشدار انبار: {count} کالا زیر حداقل موجودی است: {items}"),
    "daily_report": ("sms.template.daily_report",
                     "{store} | گزارش {date}: {invoices} فاکتور | فروش {sales} {currency} | سود {profit} {currency} | بدهی مشتریان {debt} {currency}"),
}


class _SafeDict(dict):
    """قالب با جای‌نگهدار ناشناخته هم نمی‌شکند (اشتباه تایپی مدیر نباید فروش را بخواباند)."""

    def __missing__(self, k):  # pragma: no cover - defensive
        return "{" + k + "}"


def render_template(db: Session, kind: str, **values) -> str:
    """Fill the shop-editable template for ``kind`` (§166). Unknown placeholders
    are left untouched so a typo in a template never crashes a sale."""
    key, default = TEMPLATE_KEYS[kind]
    tpl = get_setting(db, key, default) or default
    return tpl.format_map(_SafeDict(values))


def _store_ctx(db: Session) -> dict:
    cur = get_setting(db, "pos.currency", "IRT")
    return {"store": get_setting(db, "store.name", "فروشگاه"),
            "currency": "ریال" if cur == "IRR" else "تومان"}


def _fmt(n) -> str:
    try:
        return f"{float(n):,.0f}"
    except (TypeError, ValueError):
        return str(n)


def admin_phone(db: Session) -> str:
    return (get_setting(db, "sms.admin_phone", "") or get_setting(db, "store.mobile", "")).strip()


def queue_low_stock_alert(db: Session, *, rows: list[dict]) -> "SmsMessage | None":
    """§176 — SMS the manager when items fall below their minimum."""
    if get_setting(db, "sms.low_stock_alert", "false").lower() != "true":
        return None
    phone = admin_phone(db)
    if not phone or not rows:
        return None
    names = "، ".join(str(r.get("name")) for r in rows[:5])
    if len(rows) > 5:
        names += f" و {len(rows) - 5} مورد دیگر"
    text = render_template(db, "low_stock", count=len(rows), items=names, **_store_ctx(db))
    return queue_sms(db, phone=phone, text=text, reference_type="LowStock", reference_id=None)


def queue_daily_report(db: Session) -> "SmsMessage | None":
    """§175 — management summary SMS (dashboard numbers) to the admin phone."""
    from .reports import dashboard as _dashboard

    phone = admin_phone(db)
    if not phone:
        raise SmsProviderError("CONFIG_MISSING", "sms.admin_phone (یا store.mobile) تنظیم نشده است")
    from datetime import date as _date
    d = _dashboard(db)
    sales = d.get("sales", {}) or {}
    text = render_template(
        db, "daily_report",
        date=_lt_today().isoformat(),
        invoices=sales.get("invoice_count_today", 0),
        sales=_fmt(sales.get("today", 0)), profit=_fmt((d.get("profit") or {}).get("today", 0)),
        debt=_fmt((d.get("receivables") or {}).get("customer_debt", 0)), **_store_ctx(db))
    return queue_sms(db, phone=phone, text=text, reference_type="DailyReport", reference_id=None)


def retry_message(db: Session, sms_id: int) -> "SmsMessage":
    """§171 — put a FAILED message back in the queue (manual retry)."""
    msg = db.get(SmsMessage, sms_id)
    if msg is None:
        raise SmsProviderError("NOT_FOUND", "پیامک یافت نشد")
    if msg.status == "SENT":
        raise SmsProviderError("ALREADY_SENT", "این پیامک قبلاً ارسال شده است")
    msg.status = "PENDING"
    msg.retry_count = 0
    msg.error_message = None
    msg.next_retry_at = None  # manual retry sends immediately, no backoff debt
    db.flush()
    return msg


def test_connection(db: Session) -> dict:
    """§177 — provider connectivity test. Never sends a real SMS to a customer."""
    if get_setting(db, "sms.provider", "").strip() == "phone":
        seen = get_setting(db, "sms.phone_last_seen", "")
        dev = get_setting(db, "sms.phone_device", "")
        ok = bool(seen) and (datetime.utcnow() - datetime.fromisoformat(seen)).total_seconds() < 15 * 60
        return {"status": "OK" if ok else "WARN", "provider": "phone",
                "message": (f"گوشی ارسال‌کننده ({dev or 'نامشخص'}) متصل است" if ok else
                            "هنوز هیچ گوشی‌ای صف را نگرفته — در اپ موبایل «ارسال با سیم‌کارت» را روشن کنید و گوشی متصل بماند")}
    from .diagnostics import check_sms
    return check_sms(db)


# --- v2.8: outbox for the phone SIM sender ------------------------------------------

def outbox_for_phone(db: Session, device_id: str, limit: int = 20) -> list[dict]:
    """PENDING/RETRYING rows for the SIM sender; also records which device is draining."""
    _set_setting(db, "sms.phone_last_seen", datetime.utcnow().isoformat(timespec="seconds"))
    if device_id:
        _set_setting(db, "sms.phone_device", device_id)
    if get_setting(db, "sms.provider", "").strip() != "phone":
        return []
    rows = db.execute(select(SmsMessage).where(SmsMessage.status.in_(["PENDING", "RETRYING"]))
                      .order_by(SmsMessage.id.asc()).limit(limit)).scalars().all()
    return [{"id": m.id, "phone": m.phone, "text": m.text} for m in rows]


def outbox_report(db: Session, *, sms_id: int, status: str, response: str | None, error: str | None) -> SmsMessage | None:
    msg = db.get(SmsMessage, sms_id)
    if msg is None or msg.status == "SENT":
        return msg
    if status == "SENT":
        msg.status = "SENT"
        msg.sent_at = datetime.utcnow()
        msg.provider_response = response
        msg.error_message = None
        _audit(db, "SMS_SENT", msg, "phone")
    else:
        msg.retry_count = (msg.retry_count or 0) + 1
        msg.error_message = (error or "")[:500]
        max_retries = int(get_setting(db, "sms.max_retries", "5") or 5)
        msg.status = "FAILED" if msg.retry_count >= max_retries else "RETRYING"
        if msg.status == "FAILED":
            _audit(db, "SMS_FAILED", msg, "phone", error=msg.error_message)
    db.flush()
    return msg


#: v4.8.0 — سقف ردیف‌های کالا در پیامک. پیش‌فرض **صفر = بدون سقف**: هیچ خط
#: خریداری‌شده‌ای هرگز پنهان نمی‌شود (قرارداد v3.6.3). اگر فروشگاهی خواست
#: پیامک کوتاه‌تر شود، ``sms.invoice_max_items`` را روی عدد دلخواه می‌گذارد و
#: آن‌وقت باقیِ اقلام در یک ردیف صریح «و N قلم دیگر» خلاصه می‌شوند — نه حذف.
INVOICE_MAX_ITEMS = 0
#: حداکثر طول نام کالا در یک ردیف (کاراکتر) — ردیف‌ها هم‌تراز می‌مانند.
INVOICE_NAME_LIMIT = 26


def _fa_digits(text: str) -> str:
    return text.translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def _qty_txt(q) -> str:
    """۲ · ۱٫۵ — عدد بدون صفر اضافی (واحدهای وزنی درست نمایش داده شوند)."""
    f = float(q)
    return f"{f:g}".translate(str.maketrans("0123456789.", "۰۱۲۳۴۵۶۷۸۹٫"))


def _short(name: str, limit: int = INVOICE_NAME_LIMIT) -> str:
    name = " ".join(str(name or "").split())
    return name if len(name) <= limit else name[: limit - 1].rstrip() + "…"


def render_invoice_lines(db: Session, invoice, coupon_line: str = "") -> list[str]:
    """ردیف‌های مرتب پیامک فاکتور (v4.8.0 — درخواست مالک: «متن‌ها به‌هم‌ریخته نباشد»).

    ساختار ثابت و یک‌خط‌به‌ازای‌هر‌کالا:

        {store} | فاکتور {شماره} | {تاریخ}
        ۱. نام کالا  ۲ × ۵۰٬۰۰۰ = ۱۰۰٬۰۰۰
        …
        جمع کالاها: …   تخفیف: …   مالیات: …   پرداختی: …
        کد تخفیف خرید بعدی: …
        از خرید شما سپاسگزاریم — {store}

    چرا این‌طور؟ پیامک قبلی سه خط برای هر کالا داشت و روی گوشی‌های ساده به‌هم
    می‌ریخت. اینجا هر کالا **یک ردیف** است، مبالغ با جداکنندهٔ هزارگان، و
    ردیف‌های جمع همیشه در انتها و با ترتیب ثابت. اگر کالاها بیش از حد باشند،
    بقیه در یک ردیف «و N قلم دیگر» خلاصه می‌شوند تا پیامک بریده نشود.
    """
    ctx = _store_ctx(db)
    store = (ctx["store"] or "").strip() or "فروشگاه"
    cur = ctx["currency"]
    try:
        max_items = int(float(get_setting(db, "sms.invoice_max_items", str(INVOICE_MAX_ITEMS)) or INVOICE_MAX_ITEMS))
    except (TypeError, ValueError, AttributeError):   # بی‌سشن در تست/پیش‌نمایش: پیش‌فرض
        max_items = INVOICE_MAX_ITEMS
    if max_items <= 0:
        max_items = len(invoice.items or []) or 0
    try:                                               # تاریخ شمسی، مثل رسید صندوق
        from .timeservice import to_jalali
        d = _lt_today()
        jy, jm, jd = to_jalali(datetime(d.year, d.month, d.day))
        date_txt = _fa_digits(f"{jy:04d}/{jm:02d}/{jd:02d}")
    except Exception:                                  # never break a sale over a date
        date_txt = ""
    head = f"{store} | فاکتور {invoice.invoice_number}"
    if date_txt:
        head += f" | {date_txt}"

    items = sorted(list(invoice.items or []), key=lambda x: x.id or 0)
    digits = "۰۱۲۳۴۵۶۷۸۹"
    lines = [head, "────────────"]
    for n, item in enumerate(items[:max_items], 1):
        name = item.product.name if item.product else f"کالا {item.product_id}"
        row = (f"{str(n).translate(str.maketrans('0123456789', digits))}. {_short(name)}  "
               f"{_qty_txt(item.qty)} × {_fa_digits(_fmt(item.unit_sell_price))} "
               f"= {_fa_digits(_fmt(item.subtotal))}")
        if float(item.discount or 0) > 0:
            row += f" (−{_fa_digits(_fmt(item.discount))})"
        lines.append(row)
    if len(items) > max_items:
        rest = len(items) - max_items
        lines.append(f"و {str(rest).translate(str.maketrans('0123456789', digits))} قلم دیگر "
                     f"(جزئیات کامل روی رسید صندوق)")

    parts = [f"جمع کالاها: {_fa_digits(_fmt(invoice.subtotal))}"]
    if float(invoice.discount or 0) > 0:
        parts.append(f"تخفیف: {_fa_digits(_fmt(invoice.discount))}")
    if float(invoice.tax or 0) > 0:
        parts.append(f"مالیات: {_fa_digits(_fmt(invoice.tax))}")
    lines.append(" | ".join(parts))
    lines.append(f"پرداختی: {_fa_digits(_fmt(invoice.total_amount))} {cur}")
    if coupon_line.strip():
        lines.append(coupon_line.strip())
    lines.append(f"از خرید شما سپاسگزاریم — {store}")
    return lines


def render_invoice_short(db: Session, invoice, coupon_line: str = "") -> str:
    """نسخهٔ کوتاه فاکتور مخصوص «حالت الگو» (ملی‌پیامک §166).

    الگوی ثبت‌شده در پنل، تعداد متغیرهای ثابت دارد؛ اگر رسیدِ کامل (یک ردیف برای
    هر کالا) فرستاده شود، سرویس پیام را رد می‌کند. پس در این حالت همان قالب
    کوتاهِ خود فروشگاه می‌رود: «{store} | فاکتور {invoice} | مبلغ …».
    """
    ctx = _store_ctx(db)
    key, _default = TEMPLATE_KEYS["invoice"]
    try:
        tpl = (get_setting(db, key, "") or "").strip()
    except AttributeError:          # بی‌سشن (تست/پیش‌نمایش)
        tpl = ""
    if not tpl or "{items}" in tpl:
        tpl = "{store} | فاکتور {invoice} | مبلغ {amount} {currency}"
    body = tpl.format_map(_SafeDict({"store": ctx["store"], "invoice": invoice.invoice_number,
                                     "amount": _fa_digits(_fmt(invoice.total_amount)), "currency": ctx["currency"],
                                     "items": "", "customer": ""}))
    body = "\n".join(line for line in (ln.strip() for ln in body.splitlines()) if line)
    if coupon_line.strip():
        body += "\n" + coupon_line.strip()
    return body


def render_invoice_for_mode(db: Session, invoice, coupon_line: str = "") -> str:
    """متن فاکتور با توجه به روش ارسال (v4.8.0).

    * خط اختصاصی / کاوه‌نگار / گوشی → رسید مرتب (یک ردیف برای هر کالا).
    * حالت الگوی ملی‌پیامک → متن کوتاه، چون تعداد متغیرهای الگو ثابت است.
    """
    try:
        provider = (get_setting(db, "sms.provider", "") or "").strip().lower()
        mode = (get_setting(db, "sms.melipayamak_mode", "line") or "line").strip().lower()
    except AttributeError:
        provider, mode = "", "line"
    if provider == "melipayamak" and mode == "pattern":
        return render_invoice_short(db, invoice, coupon_line)
    return render_invoice(db, invoice, coupon_line)


def render_invoice(db: Session, invoice, coupon_line: str = "") -> str:
    """Complete receipt; legacy short templates must never suppress purchased lines.

    v4.8.0 — the shop-editable ``sms.template.invoice`` is honoured when it is
    rich enough to carry the sale: a template that contains ``{items}`` gets the
    ordered rows injected. A legacy one-line template (which used to drop every
    purchased line) is **upgraded**: the tidy rows are appended, never replaced.
    """
    rows = render_invoice_lines(db, invoice, coupon_line)
    key, default = TEMPLATE_KEYS["invoice"]
    try:
        tpl = (get_setting(db, key, "") or "").strip()
    except AttributeError:      # بی‌سشن (تست/پیش‌نمایش): همان چیدمان پیش‌فرض
        tpl = ""
    if tpl and "{items}" in tpl:
        ctx = _store_ctx(db)
        body = tpl.format_map(_SafeDict({"items": "\n".join(rows[1:]),
                                         "store": ctx["store"], "invoice": invoice.invoice_number,
                                         "amount": _fmt(invoice.total_amount), "currency": ctx["currency"],
                                         "customer": ""}))
        return body
    return "\n".join(rows)
