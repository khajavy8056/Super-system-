"""v3.0 — «فروشگاه نمونه»: generate one realistic year (or two) of a neighbourhood
supermarket through the REAL service layer, then back-date the timestamps.

v4.8.0 — the simulated shop now lives the new timeline too: the daily loop plays
the store-intelligence worker (dated markdown steps land on their day, exactly
like ``apply_markdown_steps`` in production), the periodic manager review accepts
the expiry cards as well (discount ladder for the living batch, «ثبت ضایعات» for
the expired one), and the finished year carries a **verification report** —
``insight_actions.health_scan`` re-checks every executed action against the data,
so a Colab run proves the suggestions were not just accepted but still hold.

Why through the service layer: checkout allocates batches, writes movements,
profit per line, ledger entries, payments, coupons; receiving writes batches,
movements and payables. So every report, the intelligence engine and the
A/B measurer see exactly what a real shop would have produced — nothing is
faked in the reports layer.

Realism knobs (deterministic, seeded):
  * ~120 products in 14 categories with real Iranian buy/sell prices (toman)
  * weekday curve (Thursday/Friday peak), monthly seasonality (Ramadan-ish dip,
    Nowruz spike, summer beverages), hour-of-day curve
  * 140 named customers with habits (regulars, VIP whales, churned ones), ~35 % of
    invoices are registered customers, some on credit
  * 4 cashiers; one has a mildly elevated void rate (so LOSS_PREV fires)
  * 3 suppliers with different price/shelf-life quality (SUPPLIER)
  * intentionally planted situations the engine must find:
      - a perishable batch received too big (EXPIRY_LADDER)
      - two dead-stock SKUs bought 5 months ago (DEAD_STOCK)
      - a fast mover with low stock (VELOCITY)
      - one SKU priced under cost (PRICE_GAP)
      - strong basket pairs (bread↔cheese, tea↔sugar, chips↔soda …) (CROSS_SELL)
      - issued cheques clustering next month (CASHFLOW)
  * ~6 % of registered customers stop coming 40–70 days before "today" (CHURN)

`generate(db, days=365)` returns a summary; `generate_backup_file(path)` builds
a standalone .db you can import from Settings → Backup.
"""
from __future__ import annotations

import json
import logging
import math
import random
from datetime import date, datetime, timedelta
from decimal import Decimal

from sqlalchemy import select, text, update
from sqlalchemy.orm import Session

from ..models import (Brand, Category, Cheque, Customer, CustomerLedgerEntry, Expense, ExpenseCategory, Invoice, InvoiceItem,
                      Payment, Product, ProductBatch, Return, StockMovement, Stocktake, StocktakeItem, Supplier, Unit, User)
from . import accounting as acc_svc
from . import catalog
from . import inventory as inv_svc
from . import pos as pos_svc
from .audit import write_audit

log = logging.getLogger("supermarket.demo")

D = Decimal

# --------------------------------------------------------------------------- catalogue
# (category, [(name, brand, buy, sell, consumer, perishable_days|None, base_daily_demand)])
CATALOG = {
    "لبنیات": [("شیر کم‌چرب ۱ لیتری", "کاله", 32000, 38000, 39000, 12, 9.0), ("ماست ۹۰۰ گرمی", "میهن", 48000, 56000, 58000, 20, 6.5),
             ("پنیر سفید ۴۰۰ گرمی", "کاله", 62000, 72000, 74000, 40, 5.0), ("دوغ ۱.۵ لیتری", "عالیس", 30000, 36000, 37000, 25, 4.0),
             ("خامه ۲۰۰ گرمی", "پگاه", 26000, 31000, 32000, 15, 2.2), ("کره ۱۰۰ گرمی", "میهن", 42000, 49000, 50000, 60, 2.8)],
    "نان و شیرینی": [("نان تست ۵۰۰ گرمی", "سه‌نان", 38000, 45000, 46000, 7, 6.0), ("کیک صبحانه", "شیرین‌عسل", 12000, 15000, 15000, 90, 5.5),
                 ("بیسکویت ساقه طلایی", "مینو", 20000, 25000, 25000, 180, 4.5), ("کلوچه نادری", "نادری", 9000, 12000, 12000, 60, 4.0)],
    "نوشیدنی": [("نوشابه کولا ۱.۵ لیتری", "زمزم", 22000, 28000, 29000, 240, 7.0), ("نوشابه پرتقالی ۳۰۰ سی‌سی", "کوکاکولا", 11000, 15000, 15000, 240, 6.0),
              ("آب معدنی ۱.۵ لیتری", "دماوند", 8000, 12000, 12000, 365, 9.0), ("آبمیوه سان‌استار ۱ لیتری", "سان‌استار", 45000, 55000, 56000, 180, 2.5),
              ("ماءالشعیر لیمو", "ایستک", 18000, 24000, 25000, 240, 3.5), ("چای کیسه‌ای ۱۰۰ عددی", "گلستان", 95000, 115000, 118000, None, 2.0),
              ("قهوه فوری ۵۰ گرمی", "نسکافه", 120000, 145000, 150000, None, 1.2)],
    "تنقلات": [("چیپس سرکه نمکی", "مزمز", 22000, 28000, 28000, 120, 6.5), ("پفک نمکی", "مینو", 14000, 18000, 18000, 120, 6.0),
             ("پاپ‌کرن پنیری", "چی‌توز", 18000, 23000, 23000, 120, 3.0), ("تخمه آفتابگردان ۲۰۰ گرمی", "مزمز", 35000, 42000, 43000, 150, 2.5),
             ("شکلات تلخ ۸۰٪", "فرمند", 28000, 35000, 35000, 240, 2.0), ("آدامس نعنایی", "بایودنت", 8000, 11000, 11000, 365, 3.5)],
    "خواربار": [("برنج ایرانی ۵ کیلویی", "طبیعت", 620000, 690000, 700000, None, 0.9), ("روغن آفتابگردان ۱.۸ لیتری", "لادن", 165000, 185000, 190000, None, 1.6),
              ("قند شکسته ۱ کیلویی", "شاهسوند", 58000, 66000, 67000, None, 2.2), ("شکر ۹۰۰ گرمی", "شاهسوند", 42000, 48000, 49000, None, 3.0),
              ("ماکارونی ۷۰۰ گرمی", "مانا", 28000, 34000, 35000, None, 3.2), ("رب گوجه ۸۰۰ گرمی", "چین‌چین", 58000, 68000, 69000, None, 2.0),
              ("تن ماهی ۱۸۰ گرمی", "طبیعت", 68000, 79000, 80000, None, 2.6), ("عدس ۹۰۰ گرمی", "خشکپاک", 60000, 70000, 72000, None, 1.2),
              ("لوبیا چیتی ۹۰۰ گرمی", "خشکپاک", 95000, 110000, 112000, None, 0.9), ("نمک تصفیه‌شده", "گلها", 9000, 12000, 12000, None, 1.6),
              ("زعفران ۱ گرمی", "سحرخیز", 140000, 165000, 170000, None, 0.5), ("سس مایونز ۴۵۰ گرمی", "دلپذیر", 55000, 64000, 65000, 180, 2.0),
              ("سس کچاپ ۴۰۰ گرمی", "بیژن", 38000, 45000, 46000, 180, 1.8)],
    "پروتئین": [("تخم‌مرغ ۲۰ عددی", "تلاونگ", 130000, 148000, 150000, 25, 3.6), ("سوسیس آلمانی ۵۰۰ گرمی", "کاله", 98000, 115000, 118000, 30, 1.8),
              ("کالباس خشک ۳۰۰ گرمی", "سولیکو", 110000, 128000, 130000, 30, 1.2), ("مرغ منجمد ۱.۸ کیلویی", "پروتئین گستر", 260000, 295000, 300000, 120, 1.0)],
    "میوه و سبزی": [("سیب زرد (کیلو)", "", 38000, 48000, 0, 14, 4.0), ("موز (کیلو)", "", 75000, 90000, 0, 6, 4.5), ("گوجه‌فرنگی (کیلو)", "", 25000, 34000, 0, 5, 4.0),
                ("خیار (کیلو)", "", 22000, 30000, 0, 6, 3.6), ("سیب‌زمینی (کیلو)", "", 18000, 25000, 0, 30, 3.5), ("پیاز (کیلو)", "", 16000, 22000, 0, 30, 3.0),
                ("لیمو ترش (کیلو)", "", 60000, 75000, 0, 12, 1.2)],
    "بهداشتی": [("شامپو ۴۰۰ میلی", "پرژک", 68000, 82000, 84000, None, 1.6), ("صابون ۱۲۵ گرمی", "گلنار", 14000, 18000, 18000, None, 2.8),
              ("خمیردندان ۱۰۰ میلی", "پونه", 38000, 46000, 47000, None, 1.8), ("دستمال کاغذی ۳۰۰ برگ", "تنو", 42000, 50000, 51000, None, 4.0),
              ("پوشک سایز ۴", "مای‌بیبی", 280000, 320000, 325000, None, 0.6), ("نوار بهداشتی", "مای‌لیدی", 45000, 54000, 55000, None, 1.2)],
    "شوینده": [("مایع ظرفشویی ۱ لیتری", "پریل", 52000, 62000, 63000, None, 2.4), ("پودر لباسشویی ۵۰۰ گرمی", "پرسیل", 48000, 57000, 58000, None, 1.8),
             ("مایع دستشویی ۵۰۰ میلی", "اکتیو", 40000, 48000, 49000, None, 1.6), ("سفیدکننده ۱ لیتری", "وایتکس", 22000, 28000, 28000, None, 1.4)],
    "کنسرو و آماده": [("کنسرو لوبیا", "دلپذیر", 38000, 45000, 46000, None, 1.6), ("کنسرو ذرت", "مهرام", 42000, 50000, 51000, None, 1.2),
                  ("نودل فوری", "الیت", 12000, 15000, 15000, 180, 3.8), ("سوپ آماده", "الیت", 18000, 22000, 22000, 240, 1.0)],
    "صبحانه": [("عسل ۵۰۰ گرمی", "خوانسار", 190000, 220000, 225000, None, 0.7), ("مربا آلبالو", "شانا", 48000, 56000, 57000, None, 0.9),
             ("کره بادام‌زمینی", "شیررضا", 85000, 98000, 100000, None, 0.7), ("غلات صبحانه", "نستله", 95000, 110000, 112000, None, 0.8),
             ("حلوا شکری", "عقاب", 32000, 38000, 39000, None, 1.6)],
    "بستنی و یخی": [("بستنی وانیلی ۱ لیتری", "میهن", 65000, 78000, 80000, 180, 1.4), ("بستنی چوبی", "دومینو", 12000, 16000, 16000, 180, 4.2),
                ("یخ در بهشت", "میهن", 9000, 12000, 12000, 180, 2.0)],
    "سیگار و متفرقه": [("کبریت", "توکلی", 2000, 3000, 3000, None, 1.5), ("باتری قلمی ۴ عددی", "سونی", 45000, 55000, 56000, None, 0.6),
                   ("کیسه زباله رول", "پاکنام", 25000, 30000, 30000, None, 1.8), ("فندک", "", 6000, 9000, 9000, None, 1.2)],
    "بچه و حیوانات": [("شیرخشک ۴۰۰ گرمی", "نان", 250000, 285000, 290000, None, 0.4), ("غذای گربه ۱ کیلویی", "رفلکس", 180000, 210000, 215000, None, 0.3)],
}

# basket affinity pairs (name fragments) with probability that the second joins when the first is in
PAIRS = [("نان تست", "پنیر سفید", 0.55), ("چای کیسه‌ای", "قند شکسته", 0.5), ("چیپس", "نوشابه کولا", 0.45), ("پفک", "نوشابه پرتقالی", 0.4),
         ("ماکارونی", "رب گوجه", 0.6), ("شیر کم‌چرب", "کیک صبحانه", 0.35), ("مرغ منجمد", "روغن آفتابگردان", 0.3), ("تخم‌مرغ", "نان تست", 0.35),
         ("سیب‌زمینی", "پیاز", 0.5), ("خیار", "گوجه‌فرنگی", 0.55), ("پودر لباسشویی", "سفیدکننده", 0.35), ("شامپو", "صابون", 0.3),
         ("بستنی چوبی", "آب معدنی", 0.3), ("نودل فوری", "سس کچاپ", 0.35), ("زعفران", "برنج ایرانی", 0.4)]

FIRST = ["علی", "محمد", "حسین", "رضا", "مهدی", "امیر", "سعید", "مریم", "فاطمه", "زهرا", "نرگس", "سارا", "لیلا", "نسرین", "مینا", "پریسا", "حمید", "مجید", "بهرام", "کامران", "الهام", "شیرین", "سمیرا", "احمد", "ناصر", "فرهاد", "نیما", "آرش", "پویا", "شهاب"]
LAST = ["احمدی", "محمدی", "رضایی", "کریمی", "موسوی", "حسینی", "جعفری", "صادقی", "نوری", "کاظمی", "رحیمی", "قاسمی", "اکبری", "عباسی", "بهرامی", "شریفی", "نظری", "زارعی", "سلطانی", "یوسفی"]

SUPPLIERS = [("پخش سراسری کاله", 0.00, 0.05), ("پخش مهرگان", 0.06, 0.30), ("بنکداری حاج‌قاسم", 0.02, 0.10)]   # (name, price premium, short-life share)

MONTH_FACTOR = {1: 1.02, 2: 0.98, 3: 1.28, 4: 0.92, 5: 0.96, 6: 1.06, 7: 1.10, 8: 1.08, 9: 1.00, 10: 0.97, 11: 0.95, 12: 1.03}   # Gregorian; March = Nowruz shopping
WEEKDAY_FACTOR = {0: 0.92, 1: 0.90, 2: 0.95, 3: 1.22, 4: 1.28, 5: 0.98, 6: 0.90}   # Mon..Sun; Thu/Fri peak (Iranian weekend)
HOURS = [(8, 0.03), (9, 0.05), (10, 0.07), (11, 0.08), (12, 0.08), (13, 0.06), (14, 0.05), (15, 0.05), (16, 0.07), (17, 0.09), (18, 0.11), (19, 0.12), (20, 0.09), (21, 0.05)]


def _rng(seed: int) -> random.Random:
    return random.Random(seed)


def _fix_created(db: Session, table: str, ids: list[int], at: datetime) -> None:
    if not ids:
        return
    db.execute(text(f"UPDATE {table} SET created_at=:at WHERE id IN ({','.join(str(i) for i in ids)})"), {"at": at})


def _stamp_journal(db: Session, source: str, source_id: int, at: datetime) -> None:
    """Backdate the generated source's journal AND its reversal, including fiscal year.

    Simulation-only: amounts and journal lines are never rewritten. This is not a
    live accounting repair operation; callers operate on an isolated demo DB.
    """
    local_day = (at + timedelta(hours=3, minutes=30)).date()
    period = acc_svc.ensure_fiscal_period(db, local_day)
    db.flush()
    db.execute(text("""UPDATE acc_journal_entries SET entry_date=:day,
        created_at=:at, updated_at=:at, fiscal_period_id=:period
        WHERE (source_type=:source AND source_id=:id) OR reversal_of_id IN
        (SELECT id FROM acc_journal_entries WHERE source_type=:source AND source_id=:id)
        """), {"day": local_day, "at": at, "period": period.id, "source": source, "id": source_id})


def _settle_demo_customer(db: Session, *, customer: Customer, amount: D, day: date,
                          admin: User, by_cheque: bool = False, due_date: date | None = None):
    """One atomic customer settlement, with exactly one accounting posting.

    ledger.settle posts cash accounting itself. A received cheque's journal is
    posted by record_cheque, so its companion ledger entry must NOT post it twice.
    The caller owns the transaction/savepoint.
    """
    from . import ledger as ledger_svc
    when = datetime.combine(day, datetime.min.time()) + timedelta(hours=10)
    if by_cheque:
        entry = ledger_svc.post_entry(db, customer_id=customer.id, entry_type="PAYMENT",
                                     amount=amount, method="CHEQUE", note="دریافت چک بابت بدهی",
                                     user_id=admin.id)
        cheque = acc_svc.record_cheque(db, direction="RECEIVED",
            number=f"SIM-R-{day.isoformat()}-{customer.id}", amount=amount,
            due_date=due_date or day + timedelta(days=20), bank_name="ملت",
            party_type="CUSTOMER", party_id=customer.id, party_name=customer.name,
            issue_date=day, description="چک دریافتی بابت تسویهٔ بدهی", user=admin)
        _fix_created(db, "acc_cheques", [cheque.id], when)
        _stamp_journal(db, "Cheque", cheque.id, when)
    else:
        result = ledger_svc.settle(db, customer_id=customer.id, amount=amount, method="CASH",
                                   note="تسویهٔ دوره‌ای", user_id=admin.id)
        entry = db.get(CustomerLedgerEntry, result["entry_id"])
        _stamp_journal(db, "CustomerLedgerEntry", entry.id, when)
    _fix_created(db, "customer_ledger_entries", [entry.id], when)
    return entry


def _stocktake_days(total_days: int) -> set[int]:
    """Roughly quarterly stocktakes; ≥3 even in a short run (tests, quick builds)."""
    if total_days <= 2:
        return set()
    marks = {total_days // 4, total_days // 2, (3 * total_days) // 4, total_days - 2}
    return {d for d in marks if 0 <= d < total_days}


def _supplier_weights(n: int) -> list[float]:
    """v3.5.9 — ``random.choices`` silently ignores a population longer than its weight list,
    so a big-store build with 15 wholesalers would have kept buying from the first three only."""
    if n <= 3:
        return [0.5, 0.25, 0.25][:n]
    return [0.34, 0.17, 0.17] + [0.32 / (n - 3)] * (n - 3)


def generate(db: Session, *, days: int = 365, seed: int = 1404, invoices_per_day: float = 95.0, progress=None,
             full_catalog: bool = False, resumable: bool = False, pause_after_days: int | None = None, event_callback=None) -> dict:
    """Build the demo store. Idempotent guard: refuses if the DB already has > 50 invoices."""
    import math
    if not 1 <= days <= 3660 or not math.isfinite(invoices_per_day) or not 1 <= invoices_per_day <= 10000:
        raise ValueError("DEMO_INVALID_SCALE: days 1..3660, invoices/day 1..10000")
    rnd = _rng(seed)
    from contextlib import nullcontext
    from . import simulation_checkpoint as checkpoint
    from . import insights as ins_clock     # v4.8.0 — ساعت شبیه‌سازی برای کل روزِ فروشگاه
    if resumable and not isinstance(db, checkpoint.ReplaySession):
        raise ValueError("RESUMABLE_REQUIRES_REPLAY_SESSION")
    if pause_after_days is not None and (not resumable or pause_after_days < 1):
        raise ValueError("PAUSE_REQUIRES_RESUMABLE_AND_POSITIVE_DAYS")
    config = checkpoint.signature(days, seed, invoices_per_day, full_catalog) if resumable else None
    saved = checkpoint.load(db, config) if resumable else None
    if saved and saved["phase"] == "complete":
        return saved["summary"]
    if saved is None:
        n_inv = db.execute(select(Invoice.id).limit(51)).all()
        if len(n_inv) > 50:
            raise RuntimeError("DEMO_ON_NONEMPTY_DB")
        today = datetime.utcnow().date()
        # Stress history consists of exactly N completed days, not N+1 dates or a
        # fabricated full current day whose evening has not happened yet.
        if full_catalog:
            from .timeservice import local_today
            today = local_today() - timedelta(days=1)
        start = today - timedelta(days=days - 1 if full_catalog else days)

        admin = db.execute(select(User).order_by(User.id)).scalars().first()
        from ..security import hash_password
        cashiers = []
        for uname, full in (("cashier1", "سمیه رستگار"), ("cashier2", "امیرحسین کیانی"), ("cashier3", "مهسا توکلی")):
            u = db.execute(select(User).where(User.username == uname)).scalar_one_or_none()
            if not u:
                u = User(username=uname, full_name=full, password_hash=hash_password("1234"), is_active=True)
                db.add(u)
                db.flush()
                try:
                    from ..models import Role
                    cashier_role = db.execute(select(Role).where(Role.name.in_(["cashier", "CASHIER", "صندوقدار"]))).scalars().first()
                    if cashier_role:
                        u.roles.append(cashier_role)
                except Exception:
                    pass
            cashiers.append(u)
        users = [admin] + cashiers
        user_weights = [0.15, 0.35, 0.30, 0.20]

        # ---- master data
        unit_piece = db.execute(select(Unit).where(Unit.name.in_(["عدد", "piece"]))).scalars().first()
        unit_kg = db.execute(select(Unit).where(Unit.name.in_(["کیلوگرم", "kg"]))).scalars().first()
        if not unit_piece:
            unit_piece = Unit(name="عدد", symbol="عدد", allow_decimal=False, decimals=0); db.add(unit_piece); db.flush()
        if not unit_kg:
            unit_kg = Unit(name="کیلوگرم", symbol="kg", allow_decimal=True, decimals=3); db.add(unit_kg); db.flush()
        sups = []
        for name, prem, short in SUPPLIERS:
            s = db.execute(select(Supplier).where(Supplier.name == name)).scalar_one_or_none() or Supplier(name=name, phone="021-" + str(rnd.randint(44000000, 88999999)), is_active=True)
            db.add(s); db.flush(); sups.append((s, prem, short))
        if full_catalog:
            # A big store buys from more than three wholesalers. This also gives the SUPPLIER
            # insight a score table long enough to matter — long enough, in fact, to need the
            # v3.5.9 evidence cap, so the stress file reproduces that screen honestly.
            for _nm, _prem, _short in (("پخش آریا", 0.04, 0.10), ("پخش بهار", 0.09, 0.18), ("پخش سپید", 0.02, 0.08),
                                       ("پخش نگین", 0.12, 0.25), ("پخش پارس", 0.06, 0.12), ("پخش زاگرس", 0.15, 0.30),
                                       ("پخش البرز", 0.03, 0.09), ("پخش سهند", 0.08, 0.16), ("پخش رویش", 0.11, 0.22),
                                       ("پخش مهر", 0.05, 0.11), ("پخش کیان", 0.13, 0.27), ("پخش آبان", 0.07, 0.14)):
                s = db.execute(select(Supplier).where(Supplier.name == _nm)).scalar_one_or_none() or Supplier(name=_nm, phone="021-" + str(rnd.randint(44000000, 88999999)), is_active=True)
                db.add(s); db.flush(); sups.append((s, _prem, _short))
        products: list[dict] = []
        bc = 6260000000000 + seed * 100
        for cat_name, items in CATALOG.items():
            cat = db.execute(select(Category).where(Category.name == cat_name)).scalar_one_or_none() or Category(name=cat_name, is_active=True)
            db.add(cat); db.flush()
            for name, brand, buy, sell, cons, shelf, demand in items:
                b = None
                if brand:
                    b = db.execute(select(Brand).where(Brand.name == brand)).scalar_one_or_none() or Brand(name=brand, is_active=True)
                    db.add(b); db.flush()
                bc += 7
                code = str(bc)
                code += str((10 - sum((3 if i % 2 else 1) * int(d) for i, d in enumerate(code[::-1]))) % 10)  # not a real GTIN check but scannable
                loose = "(کیلو)" in name
                p = db.execute(select(Product).where(Product.name == name)).scalar_one_or_none()
                if not p:
                    p = catalog.create_product(db, barcode=None if loose else code[:13], name=name, user=admin, brand_id=b.id if b else None,
                                               category_id=cat.id, unit_id=(unit_kg if loose else unit_piece).id, has_own_barcode=not loose,
                                               min_stock_alert=0)
                products.append({"p": p, "buy": buy, "sell": sell, "cons": cons, "shelf": shelf, "demand": demand, "loose": loose, "stock": 0.0, "cat": cat_name})
        by_name = {d["p"].name: d for d in products}

        # ---- v3.5.9: the FULL default catalogue as a slow-moving long tail -----------------
        # With full_catalog the store carries every SKU in the shipped bank (13,570), each with
        # real receiving history, so a stress backup exercises the whole product range and not
        # just the ~120 curated ones. These are deliberately kept OUT of the daily restock loop:
        # calling sellable() for 13k products x 365 days would never finish. They receive stock
        # on staggered days and join baskets as slow movers.
        long_tail: list[dict] = []
        if full_catalog:
            import zlib
            from . import default_catalog
            default_catalog.import_csv(db, user=admin)
            db.commit()
            known = set(by_name)
            for p in db.execute(select(Product)).scalars():
                if p.name in known:
                    continue
                # deterministic per name (hash() is salted per process, so it would not reproduce)
                h = zlib.crc32(p.name.encode("utf-8"))
                h1 = (h & 0xFFFF) / 0xFFFF
                h2 = ((h >> 16) & 0xFFFF) / 0xFFFF
                sell = int(round((18_000 + h1 * 640_000) / 1000) * 1000)
                buy = int(round(sell * (0.70 + 0.16 * h2) / 100) * 100)
                long_tail.append({"p": p, "buy": buy, "sell": sell, "cons": 0, "shelf": 0,
                                  "demand": round(0.03 + 0.30 * h2, 4), "loose": False,
                                  "stock": 0.0, "cat": "سایر"})
            rnd.shuffle(long_tail)
            log.info("demo: full catalogue loaded — %d long-tail SKUs", len(long_tail))
            if progress:
                progress(0.05)

        # Scale replenishment with traffic; increasing checkouts alone just creates
        # empty shelves instead of exercising a genuinely busy store.
        if full_catalog:
            supply_scale = max(1.0, invoices_per_day / 95.0)
            for product in products + long_tail:
                product["demand"] *= supply_scale

        # ---- customers (140): habits
        customers = []
        customer_count = max(140, min(20000, int(invoices_per_day * 8)))
        for i in range(customer_count):
            nm, ln = rnd.choice(FIRST), rnd.choice(LAST)
            phone = "0912" + str(rnd.randint(1000000, 9999999)) if i % 7 else None
            c = Customer(name=nm, last_name=ln, phone=phone, credit_enabled=(i % 5 == 0), credit_limit=D(2_000_000 if i % 5 == 0 else 0), is_active=True)
            db.add(c); db.flush()
            kind = "vip" if i < customer_count * .086 else "regular" if i < customer_count * .643 else "occasional"
            gap = {"vip": rnd.uniform(1.5, 3.5), "regular": rnd.uniform(4, 9), "occasional": rnd.uniform(14, 40)}[kind]
            churn_day = None
            if kind == "regular" and rnd.random() < 0.10:
                churn_day = today - timedelta(days=rnd.randint(40, 75))
            customers.append({"c": c, "kind": kind, "gap": gap, "next": start + timedelta(days=rnd.uniform(0, gap)), "churn": churn_day, "credit": i % 5 == 0,
                              "fav": rnd.sample(products, 6)})

        # ---- expense categories
        exp_cats = {}
        all_cats = db.execute(select(ExpenseCategory)).scalars().all()
        for nm, alts in (("اجاره", ["اجاره"]), ("برق و گاز", ["آب، برق، گاز و تلفن", "برق"]), ("حقوق", ["حقوق و دستمزد", "حقوق"]),
                         ("حمل", ["حمل و نقل", "حمل"]), ("متفرقه", ["سایر", "متفرقه"])):
            exp_cats[nm] = next((c for a in alts for c in all_cats if a in c.name), all_cats[0])

        # Utility bills are distinct events even where they share the chart-of-accounts category.
        for utility in ("آب", "برق", "گاز"):
            exp_cats[utility] = exp_cats["برق و گاز"]

        pending_expiry = []
    else:
        admin = saved["data"]["admin"]
        cashiers = saved["data"]["cashiers"]
        users = saved["data"]["users"]
        user_weights = saved["data"]["user_weights"]
        sups = saved["data"]["sups"]
        products = saved["data"]["products"]
        by_name = saved["data"]["by_name"]
        long_tail = saved["data"]["long_tail"]
        customers = saved["data"]["customers"]
        exp_cats = saved["data"]["exp_cats"]
        pending_expiry = saved["data"]["pending_expiry"]
        dead = saved["data"]["dead"]
        stats = saved["data"]["stats"]
        fx = saved["data"]["fx"]
        start = saved["data"]["start"]
        today = saved["data"]["today"]
        day = saved["data"]["day"]
        rnd.setstate(saved["rng"])

    # ---- helpers

    def receive(d: dict, when: datetime, qty: float, *, sup=None, shelf_override=None, price_mult=1.0):
        sup = sup or rnd.choices(sups, weights=_supplier_weights(len(sups)))[0]
        s, prem, short = sup
        buy = round(d["buy"] * (1 + prem) * price_mult / 100) * 100
        exp = None
        if d["shelf"]:
            life = shelf_override or (int(d["shelf"] * rnd.uniform(0.45, 0.7)) if rnd.random() < short else int(d["shelf"] * rnd.uniform(0.8, 1.2)))
            exp = (when + timedelta(days=max(2, life))).date()
        # v4.8.0 — تاریخ انقضا همان لحظهٔ دریافت ثبت می‌شود (کار واقعی انبار همین است).
        # قبلاً تاریخ‌ها تا پایان شبیه‌سازی نگه داشته می‌شدند چون صندوق هنوز ساعت
        # واقعی ماشین را «امروز» می‌گرفت و بچ‌های تاریخ‌دارِ گذشته را منقضی می‌دید.
        # حالا کل روزِ شبیه‌سازی با ساعت شبیه‌سازی اجرا می‌شود (timeservice)، پس
        # تاریخ‌ها از روز اول واقعی‌اند و موتور می‌تواند وسط سال هم کارت انقضا بسازد.
        b = catalog.receive_batch(db, product=d["p"], quantity_received=D(str(round(qty, 3 if d["loose"] else 0))), buy_price=D(buy),
                                  consumer_price=D(d["cons"]) if d["cons"] else None, sell_price=D(d["sell"]), expiry_date=exp,
                                  received_at=when, user=admin, paid_from="PAYABLE" if rnd.random() < 0.6 else "CASH", supplier_id=s.id)
        d["stock"] += float(b.quantity_received)
        db.flush()
        _fix_created(db, "product_batches", [b.id], when)
        if exp:
            pending_expiry.append((b.id, exp))
        db.execute(text("UPDATE stock_movements SET created_at=:at WHERE reference_type='ProductBatch' AND reference_id=:bid"), {"at": when, "bid": b.id})
        _stamp_journal(db, "ProductBatch", b.id, when)
        return b

    def sellable(d: dict, on: date) -> float:
        """Stock the POS would actually allocate: ACTIVE batches not expired on that day.

        v4.8.0 — تاریخ انقضا حالا از لحظهٔ دریافت ثبت می‌شود، پس این تابع هم مثل
        صندوق واقعی، بچِ تاریخ‌گذشته را «موجودی قابل فروش» نمی‌شمارد (وگرنه انبار
        از نظر برنامه پر بود ولی قفسه خالی).
        """
        rows = db.execute(select(ProductBatch.current_qty, ProductBatch.expiry_date).where(
            ProductBatch.product_id == d["p"].id, ProductBatch.status == "ACTIVE", ProductBatch.current_qty > 0)).all()
        return float(sum(q for q, exp in rows if exp is None or exp >= on))

    def order(d: dict, day: date):
        """Place a purchase order. Suppliers deliver the next morning (50 %), in two days (35 %)
        or three (15 %) — until it arrives the shelf can run empty (real lost sales)."""
        if d.get("arrives"):
            return
        d["arrives"] = day + timedelta(days=rnd.choices([1, 2, 3], weights=[0.5, 0.35, 0.15])[0])

    def morning_restock(d: dict, day: date):
        """Receive pending deliveries, then decide whether to reorder. The shop reorders when the
        low-stock alert fires (min_stock_alert) — so an accepted «smart minimum» really changes
        purchasing (orders go out days earlier); without one the order is placed only when the
        shelf is (nearly) empty, which is how most small shops actually operate."""
        d["stock"] = sellable(d, day)
        target = d["demand"] * (8 if d["shelf"] and d["shelf"] < 15 else 21)
        if d.get("arrives") and d["arrives"] <= day:
            d["arrives"] = None
            receive(d, datetime.combine(day, datetime.min.time()) + timedelta(hours=7, minutes=rnd.randint(0, 50)), max(target - d["stock"], d["demand"] * 5, 6))
            d["stock"] = sellable(d, day)
        min_alert = float(getattr(d["p"], "min_stock_alert", 0) or 0)
        if min_alert and d["stock"] <= min_alert:
            order(d, day)
        elif d["stock"] < d["demand"] * 0.6 or d["stock"] < 2:
            order(d, day)

    if saved is None:
        # ---- opening stock
        t0 = datetime.combine(start, datetime.min.time()) + timedelta(hours=7)
        for d in products:
            receive(d, t0, d["demand"] * (7 if d["shelf"] and d["shelf"] < 15 else 20))

        # planted dead stock: two SKUs over-bought 5 months ago
        dead = [by_name["غذای گربه ۱ کیلویی"], by_name["شیرخشک ۴۰۰ گرمی"]]
        for d in dead:
            d["demand"] = 0.006   # a salesman talked the owner into 60 units; they barely move
            d["planted_dead"] = True
        for cu in customers:   # nobody's "usual basket" contains the dead SKUs
            cu["fav"] = [x for x in cu["fav"] if not x.get("planted_dead")] or rnd.sample([x for x in products if not x.get("planted_dead")], 6)

        stats = {"invoices": 0, "lines": 0, "sales": 0.0, "voids": 0, "returns": 0, "credit": 0, "accepted_insights": 0, "lost_sales": 0,
                 "cash_sessions": 0, "stocktakes": 0}
        # effects of manager-accepted suggestions (filled by _manager_reviews); the simulation honours them
        fx = {"pair_boost": {}, "vip_ids": set(), "winback_ids": set(), "visit_ids": set(), "price_fixed": set(), "nudge_pairs": {}, "boosted_products": {}}
        # Do not retain every historical invoice id in Python; the database is the ledger.
        day = start
    total_days = days
    def checkpoint_state():
        return {"phase": "running", "rng": rnd.getstate(), "data": dict(
            admin=admin,
            cashiers=cashiers,
            users=users,
            user_weights=user_weights,
            sups=sups,
            products=products,
            by_name=by_name,
            long_tail=long_tail,
            customers=customers,
            exp_cats=exp_cats,
            pending_expiry=pending_expiry,
            dead=dead,
            stats=stats,
            fx=fx,
            start=start,
            today=today,
            day=day)}
    if resumable and saved is None:
        checkpoint.save(db, config, checkpoint_state())
        db.commit()
    if event_callback:
        event_callback({"phase": "days", "done": (day - start).days,
                        "total": (today - start).days + 1, "invoices": stats["invoices"]})
    completed_here = 0

    def _sim_clock(d: date) -> datetime:
        """ساعت شبیه‌سازی برای یک روز فروشگاه (۱۰ صبح تهران، مثل وقتی مدیر کار می‌کند)."""
        return datetime.combine(d, datetime.min.time()) + timedelta(hours=6, minutes=30)

    while day <= today:
        with db.atomic_day() if resumable else nullcontext():
            # v4.8.0 — کلِ روزِ شبیه‌سازی روی ساعت شبیه‌سازی اجرا می‌شود: صندوق،
            # انقضا، تایم‌لاین تخفیف و کارگر هوش فروشگاه همه همان «امروز» را
            # می‌بینند که فروشِ فردا خواهد دید. بدون این، یک سالِ شبیه‌سازی‌شده
            # نمی‌توانست رفتار نسخهٔ جدید را واقعاً تمرین کند.
            ins_clock.set_clock(_sim_clock(day))
            di = (day - start).days
            if progress:
                progress(0.05 + 0.87 * (di / total_days))   # v3.5.9: daily, mapped into the build's 5..92 %
            # ---- v4.8.0: کارگر روزانهٔ هوش فروشگاه ----------------------------------
            # پله‌های تخفیفی که مدیر پذیرفته **تاریخ** دارند؛ اگر کسی آن‌ها را روی
            # روز خودشان اعمال نکند، قیمت روی پلهٔ اول می‌ماند و سال شبیه‌سازی‌شده
            # دروغ می‌گوید. پس هر روز، ساعت موتور را روی همان روز می‌گذاریم و
            # دقیقاً همان تابعی را صدا می‌زنیم که کارگر پس‌زمینه در فروشگاه اجرا
            # می‌کند (apply_markdown_steps) — با همان نوشتن تاریخچهٔ قیمت و حسابرسی.
            _run_daily_intelligence(db, day, stats)

            if di in (total_days - 45, total_days - 20):
                db.commit()
                _manager_reviews(db, day, admin, products, customers, fx, stats, by_name)
            month_f = MONTH_FACTOR[day.month]
            wd_f = WEEKDAY_FACTOR[day.weekday()]
            growth = 1 + 0.18 * (di / total_days)   # the store grows ~18 % over the year
            n_today = max(20, int(rnd.gauss(invoices_per_day * month_f * wd_f * growth, 8)))
            if day == today and not full_catalog:
                n_today = int(n_today * 0.55)
            if di == total_days - 150:
                for d in dead:
                    receive(d, datetime.combine(day, datetime.min.time()) + timedelta(hours=9), 60, sup=sups[1])
            # daily restock in the morning
            for d in products:
                if d.get("planted_dead"):
                    d["stock"] = sellable(d, day)
                    continue
                morning_restock(d, day)
            # v3.5.9 — long-tail SKUs receive stock on staggered days, so every barcode in the
            # shipped bank ends up with a batch, a supplier and a stock movement somewhere in
            # the year instead of only the curated ~120 SKUs having history.
            if long_tail:
                per = max(1, -(-len(long_tail) // total_days))
                for x in long_tail[di * per:(di + 1) * per]:
                    if x["stock"] <= 0:
                        receive(x, datetime.combine(day, datetime.min.time()) + timedelta(hours=8, minutes=rnd.randint(0, 59)),
                                max(6.0, round(x["demand"] * rnd.randint(60, 160), 1)), sup=rnd.choice(sups))
                        x["stock"] = sellable(x, day)
            # customers due today
            due = [c for c in customers if c["next"] <= day and (not c["churn"] or day < c["churn"] or c["c"].id in fx["winback_ids"])]
            rnd.shuffle(due)
            for k in range(n_today):
                hour = rnd.choices([h for h, _ in HOURS], weights=[w for _, w in HOURS])[0]
                when = datetime.combine(day, datetime.min.time()) + timedelta(hours=hour, minutes=rnd.randint(0, 59), seconds=rnd.randint(0, 59)) - timedelta(hours=3, minutes=30)
                cust = None
                if due and rnd.random() < 0.55:
                    cust = due.pop()
                    cust["next"] = day + timedelta(days=max(1, rnd.gauss(cust["gap"], cust["gap"] * 0.3)))
                # basket
                n_items = max(1, int(rnd.lognormvariate(1.1, 0.55)))
                if cust and cust["kind"] == "vip":
                    n_items += 4
                if cust and cust["c"].id in fx["vip_ids"]:
                    n_items += 1   # the VIP coupon pulls an extra line into the basket
                if cust and cust.get("nudged_until") and day <= cust["nudged_until"] and rnd.random() < 0.7:
                    n_items += 1   # came for «the usual item» after the personal SMS — and picked one more thing
                pool = products if not cust else (cust["fav"] * 2 + products)
                weights = [max(0.05, x["demand"]) * (1.6 if (x["cat"] in ("نوشیدنی", "بستنی و یخی") and day.month in (6, 7, 8)) else 1.0) for x in pool]
                chosen: dict[int, dict] = {}
                for _ in range(n_items):
                    x = rnd.choices(pool, weights=weights)[0]
                    chosen[x["p"].id] = x
                for a, b, prob in PAIRS:
                    if any(a in x["p"].name for x in chosen.values()) and rnd.random() < prob:
                        y = by_name.get(next((n for n in by_name if b in n), ""), None)
                        if y:
                            chosen[y["p"].id] = y
                # accepted CROSS_SELL / nudges: shelf move + cashier whisper lift the attach rate
                for (pa, pb), lift in fx["pair_boost"].items():
                    if pa in chosen and pb not in chosen and rnd.random() < lift:
                        yb = next((x for x in products if x["p"].id == pb), None)
                        if yb:
                            chosen[pb] = yb
                for pid, lift in fx["boosted_products"].items():
                    if pid not in chosen and rnd.random() < lift:
                        yb = next((x for x in products if x["p"].id == pid), None)
                        if yb:
                            chosen[pid] = yb
                # v3.5.9 — slow movers join baskets, so most of the long tail accrues real
                # sales history over the year (and the reports have something to aggregate).
                if long_tail and rnd.random() < 0.10:
                    for _ in range(rnd.choices([1, 2, 3], weights=[0.7, 0.22, 0.08])[0]):
                        _x = long_tail[rnd.randrange(len(long_tail))]
                        if _x["stock"] > 0:
                            chosen[_x["p"].id] = _x
                items = []
                for x in chosen.values():
                    q = round(rnd.uniform(0.3, 2.2), 3) if x["loose"] else (rnd.choices([1, 2, 3, 6], weights=[0.7, 0.2, 0.07, 0.03])[0])
                    if x["stock"] < q:
                        # empty shelf: the customer leaves without it (lost sale) and the order goes out today
                        if not x.get("planted_dead"):
                            order(x, day)
                            stats["lost_sales"] += 1
                        continue
                    items.append((x, q))
                if not items:
                    continue
                cart = [pos_svc.CartItem(product_id=x["p"].id, quantity=D(str(q))) for x, q in items]
                # price the cart exactly like the POS does (batch prices change when the manager accepts a
                # markdown / price fix — paying the catalogue price would make the checkout fail silently)
                try:
                    total_est = float(sum(l.subtotal for l in pos_svc.validate_cart(db, [pos_svc.CartItem(product_id=x["p"].id, quantity=D(str(q))) for x, q in items])))
                except Exception:
                    total_est = sum(x["sell"] * q for x, q in items)
                on_credit = bool(cust and cust["credit"] and rnd.random() < 0.35)
                # v3.5.7 — the account tender is called ACCOUNT everywhere else
                # (pos.checkout sums on_account over method == "ACCOUNT", and the till's
                # own dropdown offers value="ACCOUNT"). This said "CREDIT", a name nothing
                # recognises, so on_account stayed 0: every "نسیه" sale was written up as
                # fully PAID, no customer debt was ever posted, and the fortnightly
                # settlement loop below then found balance_after == 0 and posted nothing
                # either. The demo store shipped with zero receivables.
                method = "ACCOUNT" if on_credit else rnd.choices(["CARD", "CASH"], weights=[0.72, 0.28])[0]
                user = rnd.choices(users, weights=user_weights)[0]
                coupon_obj = None
                if cust and cust["c"].id in (fx["vip_ids"] | fx["winback_ids"]) and rnd.random() < 0.6:
                    from ..models import Coupon
                    coupon_obj = db.execute(select(Coupon).where(Coupon.customer_id == cust["c"].id, Coupon.status == "ACTIVE",
                                                                 Coupon.used_count < Coupon.usage_limit)).scalars().first()
                    if coupon_obj and coupon_obj.valid_until and coupon_obj.valid_until < when:
                        coupon_obj = None
                inv_disc = None
                if coupon_obj:
                    # coupon validity is judged against the simulated day (the service uses the wall clock),
                    # so the discount is applied as an invoice discount and the coupon is consumed for real.
                    inv_disc = D(str(round(total_est * float(coupon_obj.discount_value) / 100))) if coupon_obj.discount_type == "PERCENT" else D(str(coupon_obj.discount_value))
                pay_amt = round(total_est - float(inv_disc or 0))
                sp = db.begin_nested()
                try:
                    inv = pos_svc.checkout(db, items=cart, payments=[{"method": method, "amount": str(pay_amt)}],
                                           user=user, customer_id=cust["c"].id if cust else None, tax_rate=D(0), invoice_discount=inv_disc)
                    if coupon_obj:
                        from ..models import CouponRedemption
                        coupon_obj.used_count += 1
                        if coupon_obj.used_count >= coupon_obj.usage_limit:
                            coupon_obj.status = "USED"
                        db.add(CouponRedemption(coupon_id=coupon_obj.id, invoice_id=inv.id, customer_id=cust["c"].id, amount=inv_disc, created_at=when))
                    sp.commit()
                except Exception as exc:  # stock race etc.
                    sp.rollback()
                    log.warning("demo checkout skipped: %s", exc)
                    continue
                for x, q in items:
                    x["stock"] -= float(q)
                db.flush()
                # back-date everything the checkout wrote
                db.execute(text("UPDATE invoices SET created_at=:at, paid_at=:at, updated_at=:at WHERE id=:id"), {"at": when, "id": inv.id})
                db.execute(text("UPDATE invoice_items SET created_at=:at WHERE invoice_id=:id"), {"at": when, "id": inv.id})
                db.execute(text("UPDATE payments SET created_at=:at WHERE invoice_id=:id"), {"at": when, "id": inv.id})
                db.execute(text("UPDATE coupon_redemptions SET created_at=:at WHERE invoice_id=:id"), {"at": when, "id": inv.id})
                db.execute(text("UPDATE stock_movements SET created_at=:at WHERE reference_type='Invoice' AND reference_id=:id"), {"at": when, "id": inv.id})
                db.execute(text("UPDATE customer_ledger_entries SET created_at=:at WHERE invoice_id=:id"), {"at": when, "id": inv.id})
                db.execute(text("UPDATE audit_logs SET created_at=:at WHERE entity_type='Invoice' AND entity_id=:id"), {"at": when, "id": inv.id})
                _stamp_journal(db, "Invoice", inv.id, when)
                stats["invoices"] += 1; stats["lines"] += len(items); stats["sales"] += float(inv.total_amount)
                if on_credit:
                    stats["credit"] += 1
                # voids: cashier2 has an elevated rate (planted LOSS_PREV)
                vr = 0.045 if user.username == "cashier2" else 0.008
                if rnd.random() < vr:
                    sp = db.begin_nested()
                    try:
                        pos_svc.void_invoice(db, invoice=inv, user=user, reason="اشتباه صندوق‌دار")
                        db.flush()
                        for x, q in items:
                            x["stock"] += float(q)
                        db.execute(text("UPDATE audit_logs SET created_at=:at WHERE action='SALE_VOIDED' AND entity_id=:id"), {"at": when + timedelta(minutes=3), "id": inv.id})
                        db.execute(text("UPDATE stock_movements SET created_at=:at WHERE reference_type='Invoice' AND reference_id=:id AND movement_type='VOID_REVERSAL'"), {"at": when + timedelta(minutes=3), "id": inv.id})
                        _stamp_journal(db, "Invoice", inv.id, when)
                        db.execute(text("UPDATE customer_ledger_entries SET created_at=:at WHERE invoice_id=:id AND entry_type='RETURN_REFUND'"), {"at": when + timedelta(minutes=3), "id": inv.id})
                        stats["voids"] += 1
                        sp.commit()
                    except Exception as exc:
                        sp.rollback(); log.warning("void skipped: %s", exc)
                elif rnd.random() < 0.012:
                    sp = db.begin_nested()
                    try:
                        it = db.execute(select(InvoiceItem).where(InvoiceItem.invoice_id == inv.id)).scalars().first()
                        if it:
                            ret = pos_svc.process_return(db, invoice=inv, invoice_item=it, qty=D(1) if not it.qty < 1 else it.qty, user=user, reason="معیوب")
                            db.flush()
                            returned_at = when + timedelta(minutes=rnd.randint(10, 50))
                            db.execute(text("UPDATE returns SET created_at=:at, updated_at=:at WHERE id=:id"), {"at": returned_at, "id": ret.id})
                            db.execute(text("UPDATE stock_movements SET created_at=:at WHERE reference_type='Return' AND reference_id=:id"), {"at": returned_at, "id": it.id})
                            _stamp_journal(db, "Return", ret.id, returned_at)
                            stats["returns"] += 1
                        sp.commit()
                    except Exception as exc:
                        sp.rollback(); log.warning("return skipped: %s", exc)
            # credit settlements: customers pay their tab every ~2 weeks
            if day.day in (1, 15):
                from . import ledger as ledger_svc
                for cu in customers:
                    if not cu["credit"]:
                        continue
                    last = db.execute(select(CustomerLedgerEntry).where(CustomerLedgerEntry.customer_id == cu["c"].id).order_by(CustomerLedgerEntry.id.desc())).scalars().first()
                    if last and float(last.balance_after) > 0 and rnd.random() < 0.8:
                        amt = float(last.balance_after) * rnd.choice([1.0, 1.0, 0.6])
                        sp = db.begin_nested()
                        try:
                            e = _settle_demo_customer(db, customer=cu["c"], amount=D(str(round(amt))),
                                day=day, admin=admin, by_cheque=rnd.random() < 0.3,
                                due_date=day + timedelta(days=rnd.randint(10, 30)))
                            db.flush()
                            _fix_created(db, "customer_ledger_entries", [e.id], datetime.combine(day, datetime.min.time()) + timedelta(hours=10))
                            _stamp_journal(db, "CustomerLedgerEntry", e.id, datetime.combine(day, datetime.min.time()) + timedelta(hours=10))
                            sp.commit()
                        except Exception as exc:
                            sp.rollback(); log.warning("settlement skipped: %s", exc)
            # monthly expenses + cheques
            if day.day == 1:
                when = datetime.combine(day, datetime.min.time()) + timedelta(hours=9)
                monthly = [("اجاره", 45_000_000, "اجارهٔ ماهانه"),
                           ("آب", rnd.randint(500_000, 1_500_000), "قبض آب"),
                           ("برق", rnd.randint(3_000_000, 6_000_000), "قبض برق"),
                           ("گاز", rnd.randint(500_000, 2_000_000), "قبض گاز"),
                           ("حمل", rnd.randint(1_500_000, 3_500_000), "هزینهٔ حمل ماهانه"),
                           ("متفرقه", rnd.randint(800_000, 2_500_000), "هزینهٔ تعمیرات و مصرفی")]
                monthly.extend(("حقوق", 14_000_000 if idx == 0 else 12_000_000,
                                "حقوق ماهانهٔ " + employee.full_name) for idx, employee in enumerate(cashiers))
                for nm, amt, description in monthly:
                    sp = db.begin_nested()
                    try:
                        e = acc_svc.record_expense(db, category_id=exp_cats[nm].id, amount=D(amt), expense_date=day, paid_from="BANK" if nm in ("اجاره", "حقوق") else "CASH", description=description, user=admin)
                        db.flush(); _fix_created(db, "acc_expenses", [e.id], when); _stamp_journal(db, "Expense", e.id, when); sp.commit()
                    except Exception as exc:
                        sp.rollback(); log.warning("expense skipped: %s", exc)
                # issued cheques to suppliers (planted: next month has a cluster)
                n_ch = 2 if day.month != today.month else 4
                for j in range(n_ch):
                    s, _, _ = rnd.choice(sups)
                    due_d = day + timedelta(days=rnd.randint(25, 55)) if day.month != today.month else today + timedelta(days=rnd.randint(6, 26))
                    sp = db.begin_nested()
                    try:
                        ch = acc_svc.record_cheque(db, direction="ISSUED", number=str(rnd.randint(100000, 999999)), amount=D(rnd.randint(35, 120) * 1_000_000),
                                                   due_date=due_d, bank_name=rnd.choice(["ملت", "ملی", "صادرات", "پاسارگاد"]), party_type="SUPPLIER", party_id=s.id,
                                                   party_name=s.name, description="بابت خرید کالا", issue_date=day, user=admin)
                        db.flush(); _fix_created(db, "acc_cheques", [ch.id], when); _stamp_journal(db, "Cheque", ch.id, when); sp.commit()
                    except Exception as exc:
                        sp.rollback(); log.warning("cheque skipped: %s", exc)
            # v3.5.7 — settle the cheques that have come due. accounting.clear_cheque()
            # and bounce_cheque() both exist, but nothing ever called them, so every
            # cheque this generator wrote stayed PENDING and the cheques report had one
            # column with anything in it: no وصول شده, no برگشت خورده, no ageing.
            due = db.execute(select(Cheque).where(Cheque.status == "PENDING",
                                                  Cheque.due_date <= day)).scalars().all()
            for ch in due:
                if rnd.random() < 0.12:
                    continue                       # genuinely still outstanding
                sp = db.begin_nested()
                try:
                    if rnd.random() < 0.07:
                        acc_svc.bounce_cheque(db, cheque_id=ch.id, user=admin)
                        if ch.direction == "RECEIVED" and ch.party_type == "CUSTOMER":
                            from . import ledger as ledger_svc
                            restored = ledger_svc.post_entry(db, customer_id=ch.party_id,
                                entry_type="ADJUSTMENT_DEBIT", amount=ch.amount,
                                method="CHEQUE", note=f"برگشت چک {ch.number}", user_id=admin.id)
                            _fix_created(db, "customer_ledger_entries", [restored.id],
                                         datetime.combine(day, datetime.min.time()) + timedelta(hours=9))
                    else:
                        acc_svc.clear_cheque(db, cheque_id=ch.id, user=admin)
                    cleared_at = datetime.combine(day, datetime.min.time()) + timedelta(hours=9)
                    _stamp_journal(db, "ChequeClear" if ch.status == "CLEARED" else "ChequeBounce", ch.id, cleared_at)
                    sp.commit()
                    # the service stamps updated_at with the wall clock; pull it back onto
                    # the simulated calendar. created_at is deliberately left alone — that
                    # is the issue date and _fix_created() would overwrite it.
                    db.execute(text("UPDATE acc_cheques SET updated_at=:at WHERE id=:id"),
                               {"at": datetime.combine(day, datetime.min.time()) + timedelta(hours=9),
                                "id": ch.id})
                except Exception as exc:
                    sp.rollback(); log.warning("cheque settle skipped: %s", exc)
            db.commit()  # bounded daily transactions; avoid month-sized WAL growth

            # ---- v4.7.0: cashier SHIFTS — one cash session per cashier per week
            # (opening float → the week's real sales → counted cash with a small
            # human difference → Z-report journal), so «شیفت‌بندی کارمندها» and the
            # shift reports have a full year of history. Runs AFTER the day's
            # commit, in its own transaction — the same isolation pattern
            # _manager_reviews uses — so a failure can never eat the day's work
            # (pysqlite SAVEPOINTs are unreliable; we don't gamble with them).
            if day.weekday() == 3:   # Thursday close: the week is summed up
                week_start = datetime.combine(day - timedelta(days=6), datetime.min.time()) + timedelta(hours=8)
                week_end = datetime.combine(day, datetime.min.time()) + timedelta(hours=21)
                for cashier in cashiers:
                    try:
                        s = acc_svc.open_cash_session(db, user=cashier, opening_float=D(3_000_000))
                        s.opened_at = week_start
                        db.flush()
                        summ = acc_svc.session_summary(db, s)
                        expected = D(str(round(summ["expected_cash"] / 1000.0) * 1000))   # counted to the nearest 1,000
                        acc_svc.close_cash_session(db, session_id=s.id, counted_cash=expected,
                                                   note=f"جمع‌بندی شیفت هفتگی — {day.isoformat()}", user=admin)
                        s.opened_at, s.closed_at = week_start, week_end
                        _fix_created(db, "acc_cash_sessions", [s.id], week_start)
                        if s.journal_entry_id:
                            _stamp_journal(db, "CashSession", s.id, week_end)
                        db.commit()
                        stats["cash_sessions"] = stats.get("cash_sessions", 0) + 1
                    except Exception as exc:
                        db.rollback()
                        log.warning("demo: cash session skipped: %r", exc)

            # ---- v4.7.0: quarterly STOCKTAKES — count a sample, small human
            # variances, completed AND approved through the real service path
            # (adjustments + STOCKTAKE movements + audit), several times a year.
            # Same own-transaction isolation as above.
            if di in _stocktake_days(total_days):
                when = datetime.combine(day, datetime.min.time()) + timedelta(hours=7)
                try:
                    batches = db.execute(
                        select(ProductBatch).where(ProductBatch.status == "ACTIVE", ProductBatch.current_qty > 0)
                        .order_by(ProductBatch.id).limit(400)).scalars().all()
                    rnd.shuffle(batches)
                    st = Stocktake(name=f"انبارگردانی دوره‌ای — {day.isoformat()}", status="DRAFT",
                                   started_at=when, created_by=admin.id, note="شمارش نمونه‌ای دوره‌ای در شبیه‌سازی یک‌ساله")
                    db.add(st)
                    db.flush()
                    for b in batches[:60]:
                        counted = b.current_qty
                        if rnd.random() < 0.18:   # a human miss here and there
                            step = max(D(1), (counted * D("0.03")).quantize(D("1")))
                            counted = max(D(0), counted + (step if rnd.random() < 0.5 else -step))
                        db.add(StocktakeItem(stocktake_id=st.id, product_id=b.product_id, batch_id=b.id,
                                             system_qty=b.current_qty, physical_qty=counted,
                                             difference=counted - b.current_qty,
                                             reason="شمارش فیزیکی", status="COUNTED",
                                             counted_at=when, counted_by=admin.id))
                    db.flush()
                    inv_svc.complete_stocktake(db, stocktake_id=st.id, user=admin)
                    inv_svc.approve_stocktake(db, stocktake_id=st.id, user=admin,
                                              reason="تأیید مدیر — شبیه‌سازی یک‌ساله")
                    st.started_at, st.completed_at = when, when + timedelta(hours=3)
                    _fix_created(db, "stocktakes", [st.id], when)
                    # (stocktake_items has no created_at — counted_at is already set per item)
                    mv_ids = [m.id for m in db.execute(
                        select(StockMovement).where(StockMovement.movement_type == "STOCKTAKE", StockMovement.created_at >= when)
                        .order_by(StockMovement.id.desc()).limit(120)).scalars().all()]
                    if mv_ids:
                        _fix_created(db, "stock_movements", mv_ids, when)
                    db.commit()
                    stats["stocktakes"] = stats.get("stocktakes", 0) + 1
                except Exception as exc:
                    db.rollback()
                    log.warning("demo: stocktake skipped: %r", exc)

            day += timedelta(days=1)
            ins_clock.set_clock(None)

            if resumable:
                checkpoint.save(db, config, checkpoint_state())
        if event_callback:
            event_callback({"phase": "days", "done": (day - start).days,
                            "total": (today - start).days + 1, "invoices": stats["invoices"]})
        completed_here += 1
        if pause_after_days is not None and completed_here >= pause_after_days and day <= today:
            raise checkpoint.SimulationPaused(f"PAUSED: completed through {day - timedelta(days=1)}; next day {day}")

    with db.atomic_day() if resumable else nullcontext():
        def stamp_expiries():
            # historical expiry dates; whatever is still on the shelf and past its date becomes EXPIRED (the waste the engine will talk about)
            for bid, exp in pending_expiry:
                db.execute(text("UPDATE product_batches SET expiry_date=:e WHERE id=:id"), {"e": exp, "id": bid})
            pending_expiry.clear()
            db.execute(text("UPDATE product_batches SET status='EXPIRED' WHERE expiry_date IS NOT NULL AND expiry_date < :t AND current_qty > 0 AND status='ACTIVE'"), {"t": today})
            db.flush()

        stamp_expiries()

        if not full_catalog:
            # ---- planted end-state situations
            now = datetime.utcnow()
            # 1) perishable over-receipt → EXPIRY_LADDER
            yog = by_name["ماست ۹۰۰ گرمی"]
            receive(yog, now - timedelta(days=2), 140, shelf_override=9)
            # 2) fast mover nearly out → VELOCITY
            water = by_name["آب معدنی ۱.۵ لیتری"]
            db.execute(update(ProductBatch).where(ProductBatch.product_id == water["p"].id, ProductBatch.status == "ACTIVE").values(current_qty=D(0)))
            receive(water, now - timedelta(hours=5), 14)
            # 3) priced under cost → PRICE_GAP
            tuna = by_name["تن ماهی ۱۸۰ گرمی"]
            db.execute(update(ProductBatch).where(ProductBatch.product_id == tuna["p"].id, ProductBatch.status == "ACTIVE").values(sell_price=D(69000)))
            # 4) consumer-price violation
            tea = by_name["چای کیسه‌ای ۱۰۰ عددی"]
            db.execute(update(ProductBatch).where(ProductBatch.product_id == tea["p"].id, ProductBatch.status == "ACTIVE").values(sell_price=D(124000)))
            stamp_expiries()
            db.commit()

        # ---- build-505: سال کامل منابع انسانی (شیفت/حضور/حقوق/مدال/اطلاعیه) ----
        try:
            stats["hr"] = _simulate_hr_year(db, admin=admin, start=start, end=today, rnd=rnd, stats=stats)
            db.commit()
        except Exception:
            db.rollback()
            stats["hr"] = {"errors": ["HR_PHASE_FAILED"]}
            log.exception("demo: HR year failed (the store is still valid without it)")

        # ---- v3.5.9: run the model on the FINAL data and actually act on it -----------------
        # A stress file that only *contains* sales proves nothing about the intelligence engine.
        # So: run every generator over the finished year, accept the strongest suggestions through
        # the real accept() path (baseline frozen, actions executed), then measure them — exactly
        # what a manager clicking «اجرا و سنجش اثر» would do.
        ins: dict = {}
        try:
            from ..models import Insight
            from . import insights as ins_svc
            if progress:
                progress(0.93)
            run_res = ins_svc.run(db, days=180)
            db.commit()
            if progress:
                progress(0.96)
            accepted = 0
            for r in db.execute(select(Insight).where(Insight.status == "NEW")
                                # v4.7.0: the owner wants suggestions EXECUTED with measured
                                # results even in the full-catalog Colab run — accept the top 12.
                                .order_by(Insight.priority.asc(), Insight.expected_gain.desc()).limit(12 if full_catalog else 14)).scalars().all():
                try:
                    ins_svc.accept(db, r, user=admin)
                    accepted += 1
                except Exception as exc:
                    db.rollback()
                    log.warning("demo: accept skipped for insight %s: %s", r.id, exc)
            db.commit()
            if progress:
                progress(0.98)
            # ---- v4.8.0: «سیستم بررسی فروشگاه» روی کل سال اجرا می‌شود ----------------
            # هر اقدامی که در طول شبیه‌سازی اجرا شده (تخفیف پله‌ای، ضایعات، تغییر قیمت،
            # کوپن…) دوباره روی داده بازبینی می‌شود؛ حاصل در خلاصهٔ اجرا می‌آید تا
            # کاربر کولب ببیند «اجرا» واقعاً انجام شده و اثرش سر جایش هست.
            verification = {"checked": 0, "lost": [], "counts": {}}
            try:
                from . import insight_actions as ia_svc
                with db.begin_nested():   # its own SAVEPOINT: a report must never poison the year
                    scan = ia_svc.health_scan(db, notify_lost=True)
                    report = ia_svc.execution_report(db)
                verification = {"checked": int(scan.get("checked", 0)),
                                "insights_checked": int(report.get("insights_checked", len(scan.get("lost") or [])) or 0),
                                "actions_checked": int(report.get("actions_checked", 0) or 0),
                                "lost": [{"insight_id": x.get("insight_id"), "kind": x.get("kind"),
                                          "type": x.get("type"), "state": x.get("state"),
                                          "detail": x.get("detail")} for x in (scan.get("lost") or [])][:20],
                                "counts": report.get("counts") or {}}
                db.flush()
            except Exception as exc:                    # never fail the build over a report
                verification["errors"] = [repr(exc)]
            ins = {"errors": run_res.get("errors", []), "generated": int(run_res.get("created", 0)) + int(run_res.get("refreshed", 0)),
                   "accepted": accepted, "measured": ins_svc.measure_all(db),
                   "open": len(db.execute(select(Insight.id).where(Insight.status == "NEW")).scalars().all()),
                   "verification": verification}
            db.commit()
        except Exception:
            db.rollback()
            ins["errors"] = ["FINAL_INSIGHT_PASS_FAILED"]
            log.exception("demo: final insight pass failed (the store is still valid without it)")
        if progress:
            progress(1.0)

        try:
            write_audit(db, action="DEMO_STORE_GENERATED", entity_type="System", entity_id=None, after={"days": days, **{k: (round(v) if isinstance(v, float) else v) for k, v in stats.items()}})
            db.commit()
        except Exception:
            db.rollback()
        summary = {"days": days, "start_date": str(start), "end_date": str(today),
                   "verification": (ins or {}).get("verification") or {"checked": 0, "lost": [], "counts": {}},
                   "months": round(days / 30.4375, 1),
                   "products": len(products), "long_tail_products": len(long_tail),
                "suppliers": len(sups), "customers": len(customers), "insights": ins,
                **{k: (round(v) if isinstance(v, float) else v) for k, v in stats.items()}}

        if resumable:
            checkpoint.save(db, config, {"phase": "complete", "summary": summary})
        return summary


def _run_daily_intelligence(db: Session, day: date, stats: dict) -> None:
    """یک تیکِ کارگر هوش فروشگاه در پایان روزِ شبیه‌سازی‌شده (v4.8.0).

    ساعت موتور روی ``day`` تنظیم می‌شود تا «امروز» همان روزِ شبیه‌سازی باشد؛ بعد:

    * ``insight_actions.apply_markdown_steps`` — پله‌های سررسیدشده روی بچ می‌نشینند
      (قیمت + تاریخچهٔ قیمت + حسابرسی + اعلان، همان مسیر تولید)،
    * ردیف‌هایی که این تابع با ساعت واقعیِ ماشین نوشته، به روزِ شبیه‌سازی برگردانده
      می‌شوند تا گزارش‌های سالانه (تاریخچهٔ قیمت، حسابرسی) تاریخ درست بدهند.

    هیچ استثنایی روزِ شبیه‌سازی را نمی‌خورد: خرابی این قلاب فقط لاگ می‌شود.
    """
    from . import insight_actions as ia_svc
    from . import insights as ins_svc

    when = datetime.combine(day, datetime.min.time()) + timedelta(hours=7)
    previous = ins_svc._CLOCK.get()          # caller (the day loop) may have its own sim clock
    try:
        with db.begin_nested():
            ins_svc.set_clock(when)
            try:
                applied = int(ia_svc.apply_markdown_steps(db) or 0)
            finally:
                ins_svc.set_clock(previous)
            if applied:
                stats["markdown_steps"] = stats.get("markdown_steps", 0) + applied
        # ردیف‌هایی که این تیک با ساعت واقعی ماشین نوشت، به روزِ شبیه‌سازی برمی‌گردند
        for table in ("price_versions", "audit_logs", "notifications"):
            db.execute(text(f"UPDATE {table} SET created_at=:t WHERE created_at > :t"), {"t": when})
        db.flush()
    except Exception as exc:                                  # a broken tick must never kill the day
        log.warning("demo: daily intelligence tick skipped on %s: %r", day, exc)


def _manager_reviews(db: Session, day: date, admin, products, customers, fx: dict, stats: dict, by_name: dict) -> None:
    """Replay what a real manager did on `day`: run the engine with the clock set to that day,
    accept the sensible suggestions through the real accept() (baseline frozen, actions executed),
    and register the behavioural consequences the rest of the simulation must honour."""
    from . import insights as ins
    from ..models import Insight
    clock = datetime.combine(day, datetime.min.time()) + timedelta(hours=6, minutes=30)   # 10:00 Tehran
    previous = ins._CLOCK.get()
    ins.set_clock(clock)
    try:
        ins.run(db)
        db.commit()
        rows = db.execute(select(Insight).where(Insight.status == "NEW")).scalars().all()
        accepted = 0
        for r in rows:
            ev = json.loads(r.evidence or "{}")
            take, only = False, None
            if r.kind == "CROSS_SELL" and accepted < 12:
                take = True
                prods = ev.get("products") or []
                a, b = (prods[0]["id"], prods[1]["id"]) if len(prods) == 2 else (None, None)
                if a and b:
                    fx["pair_boost"][(a, b)] = 0.22
                    fx["pair_boost"][(b, a)] = 0.12
            elif r.kind == "BASKET_NUDGE":
                take = True
                for rule in ev.get("rules", [])[:12]:
                    fx["pair_boost"][(rule["if"], rule["then"])] = max(fx["pair_boost"].get((rule["if"], rule["then"]), 0), 0.10)
            elif r.kind == "VIP":
                take = True
                fx["vip_ids"] |= {x["customer_id"] for x in ev.get("rows", [])}
            elif r.kind == "CHURN":
                take = True
                ids = {x["customer_id"] for x in ev.get("rows", [])}
                fx["winback_ids"] |= ids
                for c in customers:
                    if c["c"].id in ids:
                        c["churn"] = None
                        c["next"] = day + timedelta(days=random.Random(c["c"].id).randint(2, 9))
                        c["gap"] *= 1.3   # they come back, a bit less often than before
            elif r.kind == "PRICE_GAP" and ev.get("margin") is not None:
                take = True   # under-cost tuna → priced properly; unit demand dips slightly
                fx["boosted_products"][ev["product_id"]] = 0.0
                d = next((x for x in products if x["p"].id == ev["product_id"]), None)
                if d:
                    d["demand"] *= 0.93
            elif r.kind == "DEAD_STOCK":
                take = True   # bundle + shelf move: the dead stock starts to move slowly
                fx["boosted_products"][ev["product_id"]] = 0.035
            # v4.8.0 — کارت‌های انقضا هم مثل یک مدیر واقعی «اجرا» می‌شوند:
            # بچ زنده نردبان تخفیف می‌گیرد (پله‌ها بعداً روی تاریخ خودشان می‌نشینند)
            # و بچِ تاریخ‌گذشته «ثبت ضایعات» — همان دو اقدامی که در نسخهٔ جدید آمد.
            elif r.kind == "EXPIRY_LADDER" and accepted < 26:
                mode = str(ev.get("mode") or "")
                if mode == "ladder":
                    take, only = True, ["markdown_ladder"]
                    pid = ev.get("product_id")
                    if pid:
                        # حراج، تقاضای همان کالا را بالا می‌برد (اثر واقعی تخفیف پله‌ای)
                        fx["boosted_products"][pid] = max(fx["boosted_products"].get(pid, 0.0), 0.12)
                        stats["expiry_markdowns"] = stats.get("expiry_markdowns", 0) + 1
                elif mode == "waste":
                    take, only = True, ["write_off_waste"]
                    stats["expiry_waste_actions"] = stats.get("expiry_waste_actions", 0) + 1
                elif mode == "risk_only":
                    take, only = True, ["shelf_note"]
            elif r.kind == "VELOCITY" and accepted < 20:
                take, only = True, ["set_min_stock"]
            elif r.kind == "VISIT_PATTERN":
                take = True   # personal «your usual item is in» SMS: the due customers come on time and add a line
                for x in ev.get("rows", []):
                    fx["visit_ids"].add(x["customer_id"])
                for c in customers:
                    if c["c"].id in fx["visit_ids"]:
                        c["next"] = min(c["next"], day + timedelta(days=1))
                        c["nudged_until"] = day + timedelta(days=14)
            if take:
                try:
                    ins.accept(db, r, user=admin, action_types=only)
                    accepted += 1
                except Exception as exc:
                    db.rollback()
                    log.warning("demo accept skipped %s: %s", r.kind, exc)
        # demo-store prices after PRICE_GAP acceptance are already changed by the real action.
        db.execute(text("UPDATE ai_insights SET created_at=:t, updated_at=:t, last_seen_at=:t WHERE created_at > :t"), {"t": clock})
        db.execute(text("UPDATE campaigns SET created_at=:t WHERE created_at > :t"), {"t": clock})
        db.execute(text("UPDATE coupons SET created_at=:t WHERE created_at > :t"), {"t": clock})
        db.execute(text("UPDATE notifications SET created_at=:t WHERE created_at > :t"), {"t": clock})
        db.execute(text("UPDATE audit_logs SET created_at=:t WHERE created_at > :t"), {"t": clock})
        db.commit()
        stats["accepted_insights"] += accepted
        log.warning("demo manager review on %s: %d suggestions accepted", day, accepted)
    finally:
        ins.set_clock(previous)


def is_demo(db: Session) -> bool:
    from ..models import AuditLog
    return db.execute(select(AuditLog.id).where(AuditLog.action == "DEMO_STORE_GENERATED").limit(1)).first() is not None


#: what POST /api/system/restore refuses to accept — kept in step with
#: ``_REQUIRED_TABLES`` in routers/system.py so a generated file is validated
#: here rather than discovered to be broken at restore time.
_REQUIRED_TABLES = {"users", "products", "product_batches", "invoices", "audit_logs"}

#: runs in the child process, with DATABASE_URL already pointed at the new file
_CHILD = """
import json, sys
from app.database import init_db, SessionLocal, engine
from app.services import demo_store
from app.services.simulation_checkpoint import ReplaySession, SimulationPaused, file_lock
from contextlib import nullcontext

_cfg = json.loads(sys.argv[1])


def _event(event):
    print("__EVENT__" + json.dumps(event), flush=True)


def _p(frac):
    # Streamed so the parent can draw a live progress bar; flush matters more than format.
    sys.stdout.write("__PROG__%.6f\\n" % max(0.0, min(1.0, float(frac))))
    sys.stdout.flush()


with file_lock(_cfg["worker_lock"]) if _cfg.get("worker_lock") else nullcontext():
    init_db()
    session = ReplaySession(bind=engine, expire_on_commit=False) if _cfg.get("resumable") else SessionLocal()
    try:
        with session as db:
            s = demo_store.generate(db, days=_cfg["days"], seed=_cfg["seed"],
                invoices_per_day=_cfg["invoices_per_day"], full_catalog=_cfg["full_catalog"],
                progress=_p, event_callback=_event, resumable=_cfg.get("resumable", False), pause_after_days=_cfg.get("pause_after_days"))
    except SimulationPaused as exc:
        print(str(exc), flush=True)
        sys.exit(75)
print("__DEMO__" + json.dumps(s))
"""


def _jalali_periods(start: date, end: date) -> list[str]:
    """دوره‌های حقوق جلالی («1404-07») برای بازهٔ شبیه‌سازی — به‌ترتیب، بدون تکرار.

    build-508 — مبنا اولِ **ماه جلالی** است، نه میلادی؛ نسخهٔ قبلی `start.replace(day=1)`
    را روی تاریخ میلادی می‌گرفت و برای پنجره‌های کوتاهِ اوایل ماه میلادی فقط یک دوره
    برمی‌گرداند — یعنی «پرداخت‌شده/در انتظار» وابسته به روزِ اجرا می‌شد.
    """
    from .timeservice import to_jalali
    jy, jm, _jd = to_jalali(datetime.combine(start, datetime.min.time()))
    ey, em, _ejd = to_jalali(datetime.combine(end, datetime.min.time()))
    periods: list[str] = []
    while (jy, jm) <= (ey, em):
        periods.append(f"{jy}-{jm:02d}")
        jm += 1
        if jm > 12:
            jm, jy = 1, jy + 1
    return periods


def _simulate_hr_year(db, *, admin, start, end, rnd, stats) -> dict:
    """build-505 — سال کامل منابع انسانی با سرویس‌های واقعی برنامه:
    شیفت‌ها و تخصیص دائمی، حضور روزانه (ورود/خروج با ساعت شبیه‌سازی، تأخیر/ترک زودهنگام/غیبت)،
    حقوق ماهانه (DRAFT → APPROVED → PAID؛ دورهٔ آخر عمداً پرداخت‌نشده می‌ماند)،
    «مراسم اهدای مدال» بر پایهٔ عملکرد واقعی سال (فروش/انضباط/فوق‌العاده) با پاداش مالی
    که از مسیر خودِ حقوق (فیلد bonus) ثبت می‌شود، و اطلاعیه‌های داخلی برای مراسم.
    هر شکستِ جزئی فقط همان تکه را رد می‌کند — سال فروشگاه همیشه سالم می‌ماند."""
    from ..models.hr import Announcement
    from ..models import Invoice, ShiftAttendance
    from . import payroll as pay_svc
    from . import shifts as shift_svc
    from .timeservice import to_jalali

    hr: dict = {"shifts": 0, "attendance_days": 0, "late_minutes": 0,
                "payroll_paid": 0, "payroll_pending": 0, "announcements": 0,
                "medals": [], "staff": [], "errors": []}
    staff = [u for u in db.execute(select(User).where(User.is_active.is_(True))).scalars()
             if u.username != "admin"][:6]
    if not staff:
        hr["errors"].append("NO_STAFF")
        return hr

    # ---- ۱) شیفت‌ها + تخصیص دائمی (الگوی هفتگی، day="") ----
    specs = [("شیفت صبح — فروشگاه شبیه‌سازی", "07:30", "15:30"),
             ("شیفت عصر — فروشگاه شبیه‌سازی", "15:00", "22:30"),
             ("شیفت پیک — فروشگاه شبیه‌سازی", "11:00", "19:00")]
    shifts = []
    for nm, st_t, en_t in specs:
        try:
            sh = shift_svc.create_shift(db, name=nm, start_time=st_t, end_time=en_t,
                                        workdays=[], store="فروشگاه شبیه‌سازی‌شده",
                                        department="صندوق", user=admin)
            shifts.append(sh)
            hr["shifts"] += 1
        except Exception as exc:
            db.rollback()
            hr["errors"].append(f"SHIFT:{exc}")
    for i, u in enumerate(staff):
        if shifts:
            try:
                shift_svc.assign(db, shifts[i % len(shifts)], u.id, actor=admin)
            except Exception as exc:
                db.rollback()
                hr["errors"].append(f"ASSIGN:{u.username}:{exc}")

    def _parse_hhmm(v: str) -> tuple[int, int]:
        a, b = v.split(":")
        return int(a), int(b)

    # ---- ۲) حضور روزانه با سرویس واقعی (ورود/خروج روی ساعت شبیه‌سازی) ----
    if shifts:
        d = start
        while d <= end:
            roster = [u for i, u in enumerate(staff) if (d.toordinal() + i) % 7 != 3]   # چرخش روز استراحت
            for k, u in enumerate(roster):
                sh = shifts[k % len(shifts)]
                h1, m1 = _parse_hhmm(sh.start_time)
                h2, m2 = _parse_hhmm(sh.end_time)
                base_in = datetime.combine(d, datetime.min.time()) + timedelta(hours=h1, minutes=m1)
                base_out = datetime.combine(d, datetime.min.time()) + timedelta(hours=h2, minutes=m2)
                try:
                    # سرویس شیفت خودش commit می‌کند؛ SAVEPOINT اینجا معنا ندارد
                    shift_svc.clock_in(db, u, shift_id=sh.id, day=d.isoformat(),
                                       at=base_in + timedelta(minutes=rnd.choice([0, 0, 0, 0, 0, 0, 0, 4, 9, 14, 23, 38])))
                    shift_svc.clock_out(db, u, day=d.isoformat(),
                                        at=base_out + timedelta(minutes=rnd.choice([0, 0, 0, 0, 10, 25, 45, 75])))
                    hr["attendance_days"] += 1
                except Exception as exc:
                    db.rollback()
                    hr["errors"].append(f"ATT:{u.username}:{d}:{exc}")
            d += timedelta(days=1)
        db.commit()

    # ---- ۳) عملکرد واقعی سال از روی داده (نه عدد ساختگی) ----
    sales_rows = db.execute(text(
        "SELECT created_by AS user_id, COUNT(*) AS n, COALESCE(SUM(total_amount),0) AS s "
        "FROM invoices WHERE status<>'VOID' AND created_by IS NOT NULL GROUP BY created_by")).mappings().all()
    sales_by_user = {int(r["user_id"]): (int(r["n"]), float(r["s"])) for r in sales_rows}
    att_rows = db.execute(text(
        "SELECT user_id, COUNT(*) AS days, COALESCE(SUM(late_minutes),0) AS late, "
        "COALESCE(SUM(CAST((julianday(ended_at)-julianday(started_at))*24 AS REAL)),0) AS hours "
        "FROM hr_shift_attendance WHERE started_at IS NOT NULL AND ended_at IS NOT NULL GROUP BY user_id")).mappings().all()
    att_by_user = {int(r["user_id"]): dict(r) for r in att_rows}

    # ---- ۴) حقوق ماهانه (همهٔ دوره‌ها؛ دورهٔ آخر برای مدال/وضعیت پرداخت‌نشده نگه داشته می‌شود) ----
    periods = _jalali_periods(start, end)
    # build-508 — تضمینِ تاریخ‌مستقل «پرداخت‌شده + یک دوره در انتظار»: یک دورهٔ کاملِ
    # قبل از شروع هم به دوره‌ها اضافه و کامل پرداخت می‌شود (فروشگاه نمونه، قبل از
    # شبیه‌سازی هم فعالیت داشته) — وگرنه در پنجره‌های کوتاهِ اوایل ماه جلالی فقط
    # «یک دورهٔ پرداخت‌نشده» تولید می‌شد و دمو/تست‌ها به روزِ اجرا وابسته می‌شدند.
    if periods:
        pjy, pjm, _pd = to_jalali(datetime.combine(start, datetime.min.time()))
        pjm -= 1
        if pjm == 0:
            pjm, pjy = 12, pjy - 1
        prev = f"{pjy}-{pjm:02d}"
        if prev not in periods:
            periods.insert(0, prev)
    rows_by_user_period: dict[tuple[int, str], object] = {}
    for pi, per in enumerate(periods):
        last_of_year = (pi == len(periods) - 1)
        for si, u in enumerate(staff):
            base = 12_000_000 + 1_000_000 * si
            worked = round(rnd.uniform(150, 190), 1)
            overtime = 0 if si == len(staff) - 1 and rnd.random() < 0.3 else round(rnd.uniform(0, 26), 1)
            bonus = rnd.choice([0, 0, 0, 500_000, 800_000, 1_500_000])
            benefits = 1_500_000
            try:
                # سرویس حقوق خودش commit می‌کند؛ SAVEPOINT اینجا معنا ندارد
                row = pay_svc.create_entry(
                    db, user_id=u.id, period=per, user=admin,
                    base_salary=base, hourly_pay=round(base / 176 / 1000) * 1000,
                    worked_hours=worked, overtime_hours=overtime,
                    bonus=bonus, benefits=benefits, deductions=0, penalty=0,
                    note="دورهٔ شبیه‌سازی‌شدهٔ فروشگاه")
                if not last_of_year:
                    pay_svc.approve(db, row)
                    pay_svc.pay(db, row, user=admin)
                    hr["payroll_paid"] += 1
                else:
                    hr["payroll_pending"] += 1
                rows_by_user_period[(u.id, per)] = row
            except Exception as exc:
                db.rollback()
                hr["errors"].append(f"PAYROLL:{u.username}:{per}:{exc}")
        db.commit()
    last_period = periods[-1] if periods else None

    # ---- ۵) مراسم اهدای مدال — بر پایهٔ عملکرد واقعی سال، با پاداش مالی از مسیر حقوق ----
    def _metric(u):
        n, rev = sales_by_user.get(u.id, (0, 0.0))
        a = att_by_user.get(u.id, {})
        return {"user": u, "invoices": n, "revenue": rev,
                "days": int(a.get("days", 0)), "late": int(a.get("late", 0)),
                "hours": float(a.get("hours", 0.0)),
                "overtime": round(float(a.get("hours", 0.0)) - 8.0 * int(a.get("days", 0)), 1)}

    board = sorted((_metric(u) for u in staff), key=lambda m: m["revenue"], reverse=True)
    medals: dict[int, dict] = {}
    RANK = [("🥇", "مدال طلای فروش سال", 5_000_000), ("🥈", "مدال نقرهٔ فروش سال", 3_000_000),
            ("🥉", "مدال برنز فروش سال", 2_000_000)]
    for i, m in enumerate(board[:3]):
        emoji, title, bonus = RANK[i]
        medals[m["user"].id] = {"emoji": emoji, "title": title, "bonus": bonus, "m": m}
    with_life = [m for m in board if m["days"] > 0]
    if with_life:
        punct = min(with_life, key=lambda m: m["late"])
        if punct["user"].id not in medals:
            medals[punct["user"].id] = {"emoji": "⏱", "title": "مدال منضبط‌ترین سال", "bonus": 1_000_000, "m": punct}
    if board:
        tireless = max(board, key=lambda m: max(0.0, m["overtime"]))
        if tireless["user"].id not in medals:
            medals[tireless["user"].id] = {"emoji": "🌟", "title": "مدال پرتلاش‌ترین سال", "bonus": 1_000_000, "m": tireless}

    for uid, medal in medals.items():
        m = medal["m"]; u = m["user"]
        row = rows_by_user_period.get((uid, last_period)) if last_period else None
        try:
            if row is not None:
                pay_svc.update_entry(db, row, bonus=float((row.bonus or 0)) + medal["bonus"],
                                     note=f"پاداش {medal['title']} {medal['emoji']}")
                pay_svc.approve(db, row)   # دورهٔ آخر تأیید می‌شود ولی عمداً پرداخت‌نشده می‌ماند
            hr["medals"].append({"username": u.username, "full_name": u.full_name,
                                 "emoji": medal["emoji"], "title": medal["title"],
                                 "bonus": medal["bonus"],
                                 "invoices": m["invoices"], "revenue": round(m["revenue"]),
                                 "attendance_days": m["days"], "late_minutes": m["late"],
                                 "overtime_hours": max(0.0, m["overtime"])})
        except Exception as exc:
            db.rollback()
            hr["errors"].append(f"MEDAL:{u.username}:{exc}")
    db.commit()

    # ---- ۶) اطلاعیه‌های مراسم (مثل اعلان واقعی مدیر در برنامه) ----
    ceremony_time = datetime.combine(end, datetime.min.time()) + timedelta(hours=10)
    try:
        lines = [f"{medal['emoji']} {medal['full_name']} — {medal['title']} · پاداش {medal['bonus']:,} تومان"
                 for medal in hr["medals"]]
        ann = Announcement(title="🎖 مراسم اهدای مدال سال فروشگاه",
                           body="به پاس یک سال تلاش:\n" + "\n".join(lines),
                           created_by=admin.id, status="PUBLISHED", priority=2,
                           target_kind="ALL")
        db.add(ann)
        db.flush()
        _fix_created(db, "announcements", [ann.id], ceremony_time)
        hr["announcements"] += 1
        db.commit()
    except Exception as exc:
        db.rollback()
        hr["errors"].append(f"ANNOUNCE:{exc}")

    # ---- ۷) پروفایل عملکرد هر کارمند (در خلاصهٔ ماشین‌خوان شبیه‌سازی) ----
    for m in board:
        medal = medals.get(m["user"].id) or {}
        hr["staff"].append({"username": m["user"].username, "full_name": m["user"].full_name,
                            "medal": medal.get("emoji", "—"), "medal_title": medal.get("title", ""),
                            "medal_bonus": medal.get("bonus", 0),
                            "invoices": m["invoices"], "revenue": round(m["revenue"]),
                            "attendance_days": m["days"], "late_minutes": m["late"],
                            "worked_hours": round(m["hours"], 1),
                            "overtime_hours": max(0.0, m["overtime"])})
    hr["late_minutes"] = sum(int(a.get("late", 0)) for a in att_by_user.values())
    return hr


def generate_backup_file(path, *, days: int = 365, seed: int = 1404,
                         invoices_per_day: float = 95.0, compress: bool = True,
                         full_catalog: bool = False, progress=None, work_dir=None, resume: bool = False,
                         pause_after_days: int | None = None, event_callback=None) -> dict:
    """v3.5.6 — build the standalone one-year demo store.

    This module's docstring has promised ``generate_backup_file(path)`` since v3.0,
    but the function was never written: nothing could produce ``demo_store.db.gz``,
    so ``GET /api/system/demo`` always reported ``available: false`` and the
    "restore the bundled demo store" path had nothing to restore.

    It builds in a throwaway directory through a SUBPROCESS whose DATABASE_URL
    points at the new file, so the real ``init_db()`` runs unmodified — same
    ``create_all``, same alembic stamp, same ``_reconcile_schema``, same indexes,
    same ``bootstrap``. Building it any other way would drift from what an
    installed app produces, and the whole point is that restore accepts the file
    unchanged.

    The result is validated with exactly the checks ``restore`` applies
    (``PRAGMA integrity_check`` plus the required tables) before it is written
    out, so a broken file fails here instead of at the shop's counter.
    """
    import gzip
    import os
    import shutil
    import sqlite3
    import subprocess
    import sys
    import tempfile
    from pathlib import Path

    dest = Path(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    backend_dir = Path(__file__).resolve().parents[2]

    from . import simulation_checkpoint as checkpoint
    if (resume or pause_after_days is not None) and work_dir is None:
        raise ValueError("RESUME_REQUIRES_WORK_DIRECTORY")
    if work_dir and dest.resolve().is_relative_to(Path(work_dir).resolve()):
        raise ValueError("OUTPUT_MUST_BE_OUTSIDE_WORK_DIRECTORY")
    manager = checkpoint.workspace(work_dir, resume) if work_dir else tempfile.TemporaryDirectory(prefix="demostore_")
    with manager as td:
        raw = Path(td) / "demo.db"
        env = dict(os.environ)
        env["DATABASE_URL"] = f"sqlite+pysqlite:///{raw}"
        env["SUPERMARKET_LICENSE_GATE"] = "0"
        env["ADMIN_USERNAME"] = "admin"
        env["ADMIN_PASSWORD"] = "admin123"
        env["PYTHONPATH"] = os.pathsep.join([str(backend_dir), env.get("PYTHONPATH", "")])

        # v3.5.9 — streamed, not capture_output: the build can run for an hour on a big store
        # and the caller owes the user a progress bar. stderr is merged into stdout so the
        # child can never deadlock on a full pipe. Parameters travel as JSON in argv rather
        # than by %-formatting the template — a stray % in the child used to break the build.
        cfg = json.dumps({"days": int(days), "seed": int(seed),
                          "invoices_per_day": float(invoices_per_day),
                          "full_catalog": bool(full_catalog), "resumable": work_dir is not None,
                          "pause_after_days": pause_after_days,
                          "worker_lock": str(Path(td) / "worker.lock") if work_dir else None})
        proc = subprocess.Popen([sys.executable, "-u", "-c", _CHILD, cfg],
                                cwd=str(backend_dir), env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, bufsize=1)
        from collections import deque
        summary, tail_lines = None, deque(maxlen=100)
        try:
            for line in proc.stdout or []:
                line = line.rstrip("\n")
                if line.startswith("__PROG__"):
                    if progress:
                        try:
                            progress(float(line[len("__PROG__"):]))
                        except Exception:   # a broken progress callback must not kill the build
                            log.debug("progress callback failed", exc_info=True)
                elif line.startswith("__EVENT__"):
                    if event_callback:
                        event_callback(json.loads(line[len("__EVENT__"):]))
                elif line.startswith("__DEMO__"):
                    summary = json.loads(line[len("__DEMO__"):])
                else:
                    tail_lines.append(line)
            rc = proc.wait()
        except BaseException:
            proc.terminate()
            try:
                proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait()
            raise
        if rc == 75:
            raise checkpoint.SimulationPaused("\n".join(tail_lines))
        if rc != 0 or summary is None:
            raise RuntimeError("DEMO_BUILD_FAILED rc=%s\n%s" % (rc, "\n".join(list(tail_lines)[-25:])))

        snapshot = Path(td) / "export.db"
        if snapshot.exists():
            snapshot.unlink()
        source, target = sqlite3.connect(str(raw)), sqlite3.connect(str(snapshot))
        try:
            source.backup(target, pages=256, progress=(
                lambda status, remaining, total: event_callback({"phase": "snapshot", "done": total - remaining, "total": total})
                if event_callback else None))
            target.execute("DROP TABLE IF EXISTS _simulation_checkpoint")
            target.commit()
            # sqlite's connection context manager commits but does NOT close.
            # Flush any inherited WAL before copying/compressing the main file.
            target.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            target.execute("PRAGMA journal_mode=DELETE")
        finally:
            target.close()
            source.close()
        raw = snapshot
        # --- validate exactly what restore will check -----------------------
        con = sqlite3.connect(str(raw))
        try:
            integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            con.close()
        if integrity != "ok":
            raise RuntimeError(f"DEMO_INTEGRITY_FAILED: {integrity}")
        missing = _REQUIRED_TABLES - tables
        if missing:
            raise RuntimeError(f"DEMO_MISSING_TABLES: {sorted(missing)}")

        if compress:
            tmp = dest.with_suffix(dest.suffix + ".tmp")
            with open(raw, "rb") as src, gzip.open(tmp, "wb", compresslevel=6) as out:
                processed, total = 0, raw.stat().st_size
                while chunk := src.read(1 << 20):
                    out.write(chunk)
                    processed += len(chunk)
                    if event_callback:
                        event_callback({"phase": "compress", "done": processed, "total": total})
            tmp.replace(dest)
        else:
            tmp = dest.with_suffix(dest.suffix + ".tmp")
            shutil.copyfile(raw, tmp)
            tmp.replace(dest)

    summary = dict(summary or {})
    summary.update({"path": str(dest), "bytes": dest.stat().st_size,
                    "compressed": bool(compress), "tables": len(tables)})
    return summary
