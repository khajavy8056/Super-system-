@echo off
REM ============================================================================
REM  Rasa System - PORTABLE RUNNER (one click)
REM  First run: creates a local Python environment (needs internet, from PyPI).
REM  Then: starts the native Qt desktop app + local sync server for Android.
REM  Your data lives in %USERPROFILE%\RasaSystem and is never touched by this file.
REM ============================================================================
setlocal EnableExtensions
cd /d "%~dp0"

set "PY="
py -3.12 -c "import sys" >nul 2>nul && set "PY=py -3.12"
if not defined PY py -3.11 -c "import sys" >nul 2>nul && set "PY=py -3.11"
if not defined PY py -3.13 -c "import sys" >nul 2>nul && set "PY=py -3.13"
if not defined PY python -c "import sys" >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python 3.11+ was not found on this PC.
  echo Install it once with:   winget install -e --id Python.Python.3.12
  echo or download from:       https://www.python.org/downloads/
  echo (check "Add python.exe to PATH" in the installer), then run this file again.
  start "" "https://www.python.org/downloads/"
  pause
  exit /b 1
)

if not exist ".venv-local\Scripts\python.exe" (
  echo First run: preparing the local environment ^(2-3 minutes, needs internet^)...
  %PY% -m venv .venv-local
  if errorlevel 1 ( echo Could not create the environment. & pause & exit /b 1 )
  ".venv-local\Scripts\python.exe" -m pip install --upgrade pip -q
  ".venv-local\Scripts\python.exe" -m pip install -q -r "backend\requirements.txt" -r "backend\requirements-desktop.txt"
  if errorlevel 1 (
    echo Installation failed - check your internet connection and run again.
    pause
    exit /b 1
  )
  echo Environment is ready.
)

echo Starting Rasa System ...
".venv-local\Scripts\python.exe" "installer\windows\run_supermarket.py"
if errorlevel 1 pause
