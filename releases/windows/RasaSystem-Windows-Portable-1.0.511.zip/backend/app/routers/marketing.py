"""Campaigns & coupons API (§31–38)."""
from __future__ import annotations

import json
from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Campaign, CampaignRedemption, Coupon, CouponRedemption, Customer, User
from ..security import require_permission
from ..services import coupons as svc
from ..services.audit import write_audit

router = APIRouter(prefix="/marketing", tags=["marketing"])


class CampaignIn(BaseModel):
    name: str
    description: str | None = None
    discount_type: str = Field(default="PERCENT", pattern="^(PERCENT|FIXED)$")
    discount_value: Decimal = Field(default=Decimal("0"), ge=0)
    min_purchase: Decimal = Field(default=Decimal("0"), ge=0)
    max_discount: Decimal | None = Field(default=None, ge=0)
    valid_from: datetime | None = None
    valid_until: datetime | None = None
    auto_issue_threshold: Decimal | None = Field(default=None, ge=0)
    auto_issue_validity_days: int = Field(default=30, ge=1, le=3650)
    auto_issue_sms: bool = True
    status: str = Field(default="ACTIVE", pattern="^(ACTIVE|PAUSED|ENDED)$")
    # build-481 — executable benefit rules (§23): only the capabilities that fit
    # this business model and architecture are modelled; everything else stays out.
    max_purchase: Decimal | None = Field(default=None, ge=0)
    target_type: str = Field(default="ALL", pattern="^(ALL|PRODUCTS)$")
    target_ids: list[int] | None = None
    first_purchase_only: bool = False
    usage_limit: int | None = Field(default=None, ge=1)
    per_customer_limit: int | None = Field(default=None, ge=1)
    stackable: bool = False
    auto_apply: bool = False
    priority: int = Field(default=3, ge=1, le=5)


class CouponIn(BaseModel):
    code: str | None = None
    campaign_id: int | None = None
    customer_id: int | None = None
    customer_phone: str | None = None
    discount_type: str = Field(default="PERCENT", pattern="^(PERCENT|FIXED)$")
    discount_value: Decimal = Field(default=Decimal("0"), ge=0)
    min_purchase: Decimal = Field(default=Decimal("0"), ge=0)
    max_discount: Decimal | None = Field(default=None, ge=0)
    valid_from: datetime | None = None
    valid_until: datetime | None = None
    usage_limit: int = Field(default=1, ge=1, le=100000)
    note: str | None = None


class ValidateIn(BaseModel):
    code: str
    amount: Decimal = Field(ge=0)
    customer_id: int | None = None
    customer_phone: str | None = None


def _campaign_out(c: Campaign) -> dict:
    return {
        "id": c.id, "name": c.name, "description": c.description,
        "discount_type": c.discount_type, "discount_value": float(c.discount_value),
        "min_purchase": float(c.min_purchase),
        "max_discount": float(c.max_discount) if c.max_discount is not None else None,
        "valid_from": c.valid_from.isoformat() if c.valid_from else None,
        "valid_until": c.valid_until.isoformat() if c.valid_until else None,
        "auto_issue_threshold": float(c.auto_issue_threshold) if c.auto_issue_threshold else None,
        "auto_issue_validity_days": c.auto_issue_validity_days,
        "auto_issue_sms": c.auto_issue_sms,
        "status": c.status,
        "max_purchase": float(c.max_purchase) if c.max_purchase is not None else None,
        "target_type": c.target_type,
        "target_ids": json.loads(c.target_ids) if c.target_ids else None,
        "first_purchase_only": bool(c.first_purchase_only),
        "usage_limit": c.usage_limit,
        "per_customer_limit": c.per_customer_limit,
        "stackable": bool(c.stackable),
        "auto_apply": bool(c.auto_apply),
        "priority": c.priority,
        "used_count": c.used_count or 0,
        "source_insight_id": c.source_insight_id,
    }


def _coupon_out(c: Coupon) -> dict:
    return {
        "id": c.id, "code": c.code, "campaign_id": c.campaign_id,
        "customer_id": c.customer_id, "customer_phone": c.customer_phone,
        "discount_type": c.discount_type, "discount_value": float(c.discount_value),
        "min_purchase": float(c.min_purchase),
        "max_discount": float(c.max_discount) if c.max_discount is not None else None,
        "valid_from": c.valid_from.isoformat() if c.valid_from else None,
        "valid_until": c.valid_until.isoformat() if c.valid_until else None,
        "usage_limit": c.usage_limit, "used_count": c.used_count,
        "status": c.status, "note": c.note,
        "created_at": c.created_at.isoformat() if c.created_at else None,
    }


# --- campaigns ----------------------------------------------------------------

@router.get("/campaigns")
def list_campaigns(db: Session = Depends(get_db),
                   _: User = Depends(require_permission("marketing.view"))):
    rows = db.execute(select(Campaign).order_by(Campaign.id.desc())).scalars()
    return [_campaign_out(c) for c in rows]


def _campaign_values(body: CampaignIn) -> dict:
    data = body.model_dump()
    targets = data.pop("target_ids", None)
    data["target_ids"] = json.dumps([int(x) for x in targets], ensure_ascii=False) if targets else None
    return data


@router.post("/campaigns", status_code=201)
def create_campaign(body: CampaignIn, db: Session = Depends(get_db),
                    user: User = Depends(require_permission("marketing.manage"))):
    c = Campaign(**_campaign_values(body), created_by=user.id)
    db.add(c)
    db.flush()
    write_audit(db, action="CAMPAIGN_CREATED", user_id=user.id, entity_type="Campaign",
                entity_id=c.id, after={"name": c.name})
    db.commit()
    return _campaign_out(c)


@router.patch("/campaigns/{campaign_id}")
def update_campaign(campaign_id: int, body: CampaignIn, db: Session = Depends(get_db),
                    user: User = Depends(require_permission("marketing.manage"))):
    c = db.get(Campaign, campaign_id)
    if not c:
        raise HTTPException(status_code=404, detail="CAMPAIGN_NOT_FOUND")
    # §22 — editing an ACTIVE campaign changes FUTURE behaviour only: invoices
    # already granted keep their immutable snapshot (campaign_name/benefit on the
    # invoice row + campaign_redemptions), never re-derived from this row.
    before = {k: _campaign_out(c).get(k) for k in ("name", "status", "discount_value", "valid_until")}
    for k, v in _campaign_values(body).items():
        setattr(c, k, v)
    write_audit(db, action="CAMPAIGN_UPDATED", user_id=user.id, entity_type="Campaign",
                entity_id=c.id, before=before, after={"name": c.name, "status": c.status})
    db.commit()
    return _campaign_out(c)


# --- coupons ------------------------------------------------------------------

@router.get("/coupons")
def list_coupons(q: str | None = None, status: str | None = None,
                 customer_id: int | None = None, limit: int = Query(100, le=1000),
                 db: Session = Depends(get_db),
                 _: User = Depends(require_permission("marketing.view"))):
    stmt = select(Coupon).order_by(Coupon.id.desc())
    if q:
        stmt = stmt.where(Coupon.code.ilike(f"%{q.strip().upper()}%") |
                          Coupon.customer_phone.ilike(f"%{q.strip()}%"))
    if status:
        stmt = stmt.where(Coupon.status == status.upper())
    if customer_id:
        stmt = stmt.where(Coupon.customer_id == customer_id)
    return [_coupon_out(c) for c in db.execute(stmt.limit(limit)).scalars()]


@router.post("/coupons", status_code=201)
def create_coupon(body: CouponIn, db: Session = Depends(get_db),
                  user: User = Depends(require_permission("marketing.manage"))):
    code = (body.code or svc.generate_code()).strip().upper()
    if svc.get_by_code(db, code):
        raise HTTPException(status_code=409, detail="COUPON_CODE_EXISTS")
    phone = body.customer_phone
    if body.customer_id and not phone:
        cust = db.get(Customer, body.customer_id)
        phone = cust.phone if cust else None
    c = Coupon(**{**body.model_dump(exclude={"code", "customer_phone"}),
                  "code": code, "customer_phone": phone},
               created_by=user.id)
    db.add(c)
    db.flush()
    write_audit(db, action="COUPON_CREATED", user_id=user.id, entity_type="Coupon",
                entity_id=c.id, after={"code": c.code})
    db.commit()
    return _coupon_out(c)


@router.post("/coupons/{coupon_id}/block")
def block_coupon(coupon_id: int, db: Session = Depends(get_db),
                 user: User = Depends(require_permission("marketing.manage"))):
    c = db.get(Coupon, coupon_id)
    if not c:
        raise HTTPException(status_code=404, detail="COUPON_NOT_FOUND")
    c.status = "BLOCKED"
    write_audit(db, action="COUPON_BLOCKED", user_id=user.id, entity_type="Coupon",
                entity_id=c.id)
    db.commit()
    return _coupon_out(c)


@router.post("/coupons/validate")
def validate_coupon(body: ValidateIn, db: Session = Depends(get_db),
                    _: User = Depends(require_permission("pos.sell"))):
    """Read-only evaluation used by the POS before checkout. Never consumes."""
    try:
        res = svc.evaluate(db, code=body.code, amount=body.amount,
                           customer_id=body.customer_id, customer_phone=body.customer_phone)
    except svc.CouponError as exc:
        raise HTTPException(status_code=422, detail={"code": exc.code, "message": exc.message})
    return {**res, "discount": float(res["discount"]),
            "discount_value": float(res["discount_value"]),
            "min_purchase": float(res["min_purchase"]),
            "max_discount": float(res["max_discount"]) if res["max_discount"] is not None else None}


@router.get("/coupons/{coupon_id}/redemptions")
def coupon_redemptions(coupon_id: int, db: Session = Depends(get_db),
                       _: User = Depends(require_permission("marketing.view"))):
    rows = db.execute(
        select(CouponRedemption).where(CouponRedemption.coupon_id == coupon_id)
        .order_by(CouponRedemption.id.desc())
    ).scalars()
    return [{"id": r.id, "invoice_id": r.invoice_id, "customer_id": r.customer_id,
             "amount": float(r.amount), "created_at": r.created_at.isoformat()} for r in rows]


@router.get("/stats")
def marketing_stats(db: Session = Depends(get_db),
                    _: User = Depends(require_permission("marketing.view"))):
    total = int(db.execute(select(func.count()).select_from(Coupon)).scalar_one())
    by_status = dict(db.execute(
        select(Coupon.status, func.count()).group_by(Coupon.status)
    ).all())
    redeemed_value = float(db.execute(
        select(func.coalesce(func.sum(CouponRedemption.amount), 0))
    ).scalar_one())
    # build-511 — تحلیلِ هر جشنواره (درخواست مالک: «همه‌چیز مشخص باشد، با نمودار و جدول»)
    issued_sq = (
        select(Coupon.campaign_id.label("cid"), func.count().label("n"))
        .group_by(Coupon.campaign_id).subquery()
    )
    red_sq = (
        select(CampaignRedemption.campaign_id.label("cid"),
               func.count().label("n"),
               func.coalesce(func.sum(CampaignRedemption.amount), 0).label("value"),
               func.max(CampaignRedemption.created_at).label("last"))
        .group_by(CampaignRedemption.campaign_id).subquery()
    )
    detail_rows = db.execute(
        select(Campaign, func.coalesce(issued_sq.c.n, 0), func.coalesce(red_sq.c.n, 0),
               func.coalesce(red_sq.c.value, 0), red_sq.c.last)
        .outerjoin(issued_sq, issued_sq.c.cid == Campaign.id)
        .outerjoin(red_sq, red_sq.c.cid == Campaign.id)
        .order_by(Campaign.used_count.desc(), Campaign.id.desc())
    ).all()
    campaigns_detail = [{
        "id": c.id, "name": c.name, "status": c.status,
        "discount_type": c.discount_type, "discount_value": float(c.discount_value or 0),
        "used_count": int(c.used_count or 0), "usage_limit": c.usage_limit,
        "issued_coupons": int(issued or 0), "redemptions": int(red_n or 0),
        "redeemed_value": float(red_v or 0),
        "last_used": last.isoformat() if last else None,
    } for c, issued, red_n, red_v, last in detail_rows]
    by_day_rows = db.execute(
        select(func.date(CampaignRedemption.created_at).label("day"), func.count())
        .group_by(func.date(CampaignRedemption.created_at))
        .order_by(func.date(CampaignRedemption.created_at).desc()).limit(30)
    ).all()
    by_day = [{"day": str(day), "n": int(n)} for day, n in reversed(by_day_rows)]
    return {"total_coupons": total, "by_status": by_status,
            "redeemed_value": redeemed_value,
            "campaigns": int(db.execute(select(func.count()).select_from(Campaign)).scalar_one()),
            #: build-511 — نمودار مصرف هر جشنواره + روند استفاده
            "campaigns_detail": campaigns_detail,
            "redemptions_by_day": by_day}
