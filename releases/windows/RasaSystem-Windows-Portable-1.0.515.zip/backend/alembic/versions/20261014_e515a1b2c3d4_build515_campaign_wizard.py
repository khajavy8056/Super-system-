# -*- coding: utf-8 -*-
"""build-515 — جادوگر تعریف جشنواره: شرط تعداد خرید.

Changes (additive — no data is touched):

* ``campaigns.min_purchase_count`` — شرط «بعد از N خرید»: پاداش/صدور کوپن
  پس از رسیدن تعداد خریدهای مشتری به N فعال می‌شود (صفر = غیرفعال). مکمل
  ``min_purchase`` (مبلغی) برای جادوگر ۸ گامی تعریف جشنواره.
* ``campaigns.reward_next_only`` — پاداش فقط کوپن خرید بعدی است (نوع «هدیهٔ
  خرید بعدی» جادوگر)، نه تخفیف همین فاکتور.

Revision ID: e515a1b2c3d4
Revises: d4930f0f4930
Create Date: 2026-10-14
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "e515a1b2c3d4"
down_revision: Union[str, None] = "d4930f0f4930"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("campaigns", sa.Column("min_purchase_count", sa.Integer(),
                                         nullable=False, server_default="0"))
    op.add_column("campaigns", sa.Column("reward_next_only", sa.Boolean(),
                                         nullable=False, server_default=sa.false()))


def downgrade() -> None:
    op.drop_column("campaigns", "min_purchase_count")
